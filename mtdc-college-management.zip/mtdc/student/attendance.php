<?php
require_once __DIR__ . '/../includes/auth.php';
require_student();
$pdo = db();
$sid = (int)$_SESSION['student_id'];

$month = $_GET['m'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $month)) $month = date('Y-m');

/* overall */
$o = $pdo->prepare("SELECT COUNT(*) total, SUM(status='Present') present FROM attendance WHERE student_id=?");
$o->execute([$sid]);
$ov = $o->fetch();
$ovPct = $ov['total'] ? round($ov['present'] / $ov['total'] * 100, 1) : 0;

/* this month rows */
$st = $pdo->prepare("SELECT * FROM attendance WHERE student_id=? AND DATE_FORMAT(att_date,'%Y-%m')=? ORDER BY att_date");
$st->execute([$sid, $month]);
$rows = $st->fetchAll();
$mTotal = count($rows);
$mPresent = count(array_filter($rows, fn($r) => $r['status'] === 'Present'));

/* month-wise summary */
$ms = $pdo->prepare("SELECT DATE_FORMAT(att_date,'%Y-%m') ym, COUNT(*) total, SUM(status='Present') present
  FROM attendance WHERE student_id=? GROUP BY ym ORDER BY ym DESC");
$ms->execute([$sid]);
$monthly = $ms->fetchAll();

$pageTitle = 'My Attendance';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">My Attendance</h1></div>

<div class="grid grid-4">
  <div class="stat <?= $ovPct >= 75 ? 'green' : 'red' ?>"><div class="num"><?= $ov['total'] ? $ovPct . '%' : '—' ?></div><div class="lbl">Overall Percentage</div></div>
  <div class="stat"><div class="num"><?= (int)$ov['total'] ?></div><div class="lbl">Total Working Days Marked</div></div>
  <div class="stat green"><div class="num"><?= (int)$ov['present'] ?></div><div class="lbl">Days Present</div></div>
  <div class="stat red"><div class="num"><?= (int)$ov['total'] - (int)$ov['present'] ?></div><div class="lbl">Days Absent</div></div>
</div>

<?php if ($ov['total'] && $ovPct < 75): ?>
<div class="alert alert-err" style="margin-top:16px">⚠ Your attendance is below 75%. You may not be eligible to write university exams. Please meet your class in-charge.</div>
<?php endif; ?>

<div class="grid grid-2" style="margin-top:20px">
  <div class="card">
    <h2>Daily Record</h2>
    <form class="inline-form" method="get" style="margin-bottom:12px">
      <div><label>Month</label><input type="month" name="m" value="<?= e($month) ?>" max="<?= date('Y-m') ?>"></div>
      <button class="btn btn-primary btn-sm">View</button>
    </form>
    <p style="margin-bottom:10px;font-size:13.5px">This month: <b><?= $mPresent ?></b> present / <b><?= $mTotal ?></b> marked
      <?php if ($mTotal): ?>(<?= round($mPresent / $mTotal * 100, 1) ?>%)<?php endif; ?></p>
    <div class="table-wrap" style="max-height:380px;overflow-y:auto"><table>
      <tr><th>Date</th><th>Day</th><th>Status</th></tr>
      <?php if (!$rows): ?><tr><td colspan="3">No attendance marked in this month.</td></tr><?php endif; ?>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= e(date('d-m-Y', strtotime($r['att_date']))) ?></td>
        <td><?= e(date('l', strtotime($r['att_date']))) ?></td>
        <td><span class="badge <?= $r['status'] === 'Present' ? 'badge-ok' : 'badge-err' ?>"><?= e($r['status']) ?></span></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  </div>

  <div class="card">
    <h2>Month-wise Summary</h2>
    <div class="table-wrap"><table>
      <tr><th>Month</th><th class="num">Marked</th><th class="num">Present</th><th>Percentage</th></tr>
      <?php foreach ($monthly as $m):
          $pct = round($m['present'] / $m['total'] * 100, 1); ?>
      <tr>
        <td><?= e(date('F Y', strtotime($m['ym'] . '-01'))) ?></td>
        <td class="num"><?= (int)$m['total'] ?></td>
        <td class="num"><?= (int)$m['present'] ?></td>
        <td style="min-width:140px">
          <div class="pbar <?= $pct < 75 ? 'low' : '' ?>"><span style="width:<?= $pct ?>%"></span></div>
          <small><?= $pct ?>%</small>
        </td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
