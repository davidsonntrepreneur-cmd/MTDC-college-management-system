<?php
require_once __DIR__ . '/../includes/auth.php';
require_student();
$pdo = db();
$sid = (int)$_SESSION['student_id'];

$st = $pdo->prepare('SELECT * FROM students WHERE id=?');
$st->execute([$sid]);
$me = $st->fetch();

$days = [1=>'Monday',2=>'Tuesday',3=>'Wednesday',4=>'Thursday',5=>'Friday',6=>'Saturday'];
$tt = $pdo->prepare('SELECT t.*, s.code sub_code, s.name sub_name FROM timetable t
    LEFT JOIN subjects s ON s.id=t.subject_id
    WHERE t.course_id=? AND t.year=? AND t.section=?');
$tt->execute([$me['course_id'], $me['year'], $me['section']]);
$slots = [];
$maxPeriod = 7;
foreach ($tt->fetchAll() as $row) { $slots[$row['day_of_week']][$row['period_no']] = $row; }

$pageTitle = 'Timetable';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">Class Timetable</h1>
  <span class="badge badge-info">Year <?= (int)$me['year'] ?> · Section <?= e($me['section']) ?></span></div>

<div class="card">
  <?php if (!$slots): ?>
  <p>Timetable has not been published for your class yet.</p>
  <?php else: ?>
  <div class="table-wrap"><table class="tt-table">
    <tr><th>Day</th><?php for ($p=1;$p<=$maxPeriod;$p++): ?><th>Period <?= $p ?></th><?php endfor; ?></tr>
    <?php foreach ($days as $dn => $d): ?>
    <tr>
      <td><b><?= $d ?></b></td>
      <?php for ($p=1;$p<=$maxPeriod;$p++): $sl = $slots[$dn][$p] ?? null; ?>
      <td>
        <?php if ($sl): ?>
          <div class="tt-sub"><?= e($sl['sub_code'] ?: '—') ?></div>
          <div class="tt-fac"><?= e($sl['sub_name']) ?></div>
          <div class="tt-fac"><?= e($sl['faculty']) ?></div>
          <div class="tt-fac"><?= e(substr($sl['start_time'],0,5)) ?>–<?= e(substr($sl['end_time'],0,5)) ?></div>
        <?php else: ?><span style="color:#c3c9d6">—</span><?php endif; ?>
      </td>
      <?php endfor; ?>
    </tr>
    <?php endforeach; ?>
  </table></div>
  <p class="no-print" style="margin-top:12px"><button class="btn btn-sm btn-gold" onclick="window.print()">🖨 Print</button></p>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
