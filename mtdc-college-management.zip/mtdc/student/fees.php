<?php
require_once __DIR__ . '/../includes/auth.php';
require_student();
$pdo = db();
$sid = (int)$_SESSION['student_id'];

$st = $pdo->prepare('SELECT s.*, c.name course_name FROM students s JOIN courses c ON c.id=s.course_id WHERE s.id=?');
$st->execute([$sid]);
$me = $st->fetch();

$fs = $pdo->prepare('SELECT * FROM fee_structure WHERE course_id=? AND year=? AND academic_year=? ORDER BY id');
$fs->execute([$me['course_id'], $me['year'], CURRENT_ACADEMIC_YEAR]);
$structure = $fs->fetchAll();
$totalFee = array_sum(array_column($structure, 'amount'));

$fp = $pdo->prepare('SELECT * FROM fee_payments WHERE student_id=? ORDER BY payment_date DESC, id DESC');
$fp->execute([$sid]);
$payments = $fp->fetchAll();
$paidThisAY = 0;
foreach ($payments as $p) if ($p['academic_year'] === CURRENT_ACADEMIC_YEAR) $paidThisAY += (float)$p['amount'];
$balance = max($totalFee - $paidThisAY, 0);

$pageTitle = 'My Fees';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">My Fees</h1>
  <span class="badge badge-info">AY <?= e(CURRENT_ACADEMIC_YEAR) ?></span></div>

<div class="grid grid-4">
  <div class="stat"><div class="num"><?= money($totalFee) ?></div><div class="lbl">Total Fee (This Year)</div></div>
  <div class="stat green"><div class="num"><?= money($paidThisAY) ?></div><div class="lbl">Paid</div></div>
  <div class="stat <?= $balance > 0 ? 'red' : 'green' ?>"><div class="num"><?= money($balance) ?></div><div class="lbl">Balance Due</div></div>
  <div class="stat gold"><div class="num"><?= count($payments) ?></div><div class="lbl">Total Receipts</div></div>
</div>

<div class="grid grid-2" style="margin-top:20px">
  <div class="card">
    <h2>Fee Structure — <?= e($me['course_name']) ?>, Year <?= (int)$me['year'] ?></h2>
    <div class="table-wrap"><table>
      <tr><th>Fee Type</th><th class="num">Amount</th><th>Due Date</th></tr>
      <?php if (!$structure): ?><tr><td colspan="3">Fee structure not yet published for your course/year.</td></tr><?php endif; ?>
      <?php foreach ($structure as $f): ?>
      <tr>
        <td><?= e($f['fee_type']) ?></td>
        <td class="num"><?= money($f['amount']) ?></td>
        <td><?= $f['due_date'] ? e(date('d-m-Y', strtotime($f['due_date']))) : '—' ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if ($structure): ?><tr><th>Total</th><th class="num"><?= money($totalFee) ?></th><th></th></tr><?php endif; ?>
    </table></div>
    <?php if ($balance > 0): ?>
    <div class="alert alert-err" style="margin-top:12px">Balance of <b><?= money($balance) ?></b> is pending. Please pay at the college office.</div>
    <?php else: ?>
    <div class="alert alert-ok" style="margin-top:12px">No dues pending for this academic year. Thank you!</div>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2>Payment History</h2>
    <div class="table-wrap"><table>
      <tr><th>Receipt No</th><th>Date</th><th class="num">Amount</th><th>Mode</th><th></th></tr>
      <?php if (!$payments): ?><tr><td colspan="5">No payments recorded yet.</td></tr><?php endif; ?>
      <?php foreach ($payments as $p): ?>
      <tr>
        <td><b><?= e($p['receipt_no']) ?></b></td>
        <td><?= e(date('d-m-Y', strtotime($p['payment_date']))) ?></td>
        <td class="num"><?= money($p['amount']) ?></td>
        <td><?= e($p['mode']) ?></td>
        <td><a class="btn btn-sm btn-gold" href="<?= base_url('receipt.php?id=' . $p['id']) ?>" target="_blank">🖨 Receipt</a></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
    <p class="no-print" style="margin-top:12px"><button class="btn btn-sm btn-gold" onclick="window.print()">🖨 Print Statement</button></p>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
