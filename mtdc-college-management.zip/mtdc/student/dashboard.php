<?php
require_once __DIR__ . '/../includes/auth.php';
require_student();
$pdo = db();
$sid = (int)$_SESSION['student_id'];

$st = $pdo->prepare('SELECT s.*, c.name course_name, c.code course_code FROM students s JOIN courses c ON c.id=s.course_id WHERE s.id=?');
$st->execute([$sid]);
$me = $st->fetch();

/* attendance % overall */
$a = $pdo->prepare("SELECT COUNT(*) total, SUM(status='Present') present FROM attendance WHERE student_id=?");
$a->execute([$sid]);
$att = $a->fetch();
$attPct = $att['total'] ? round($att['present'] / $att['total'] * 100, 1) : null;

/* fee balance */
$f = $pdo->prepare("SELECT
  (SELECT COALESCE(SUM(amount),0) FROM fee_structure WHERE course_id=? AND year=? AND academic_year=?) total_fee,
  (SELECT COALESCE(SUM(amount),0) FROM fee_payments WHERE student_id=? AND academic_year=?) paid");
$f->execute([$me['course_id'], $me['year'], CURRENT_ACADEMIC_YEAR, $sid, CURRENT_ACADEMIC_YEAR]);
$fee = $f->fetch();
$balance = max((float)$fee['total_fee'] - (float)$fee['paid'], 0);

/* latest exam average */
$m = $pdo->prepare("SELECT e.name, AVG(m.marks_obtained / m.max_marks * 100) pct
  FROM marks m JOIN exams e ON e.id=m.exam_id
  WHERE m.student_id=? GROUP BY e.id ORDER BY e.id DESC LIMIT 1");
$m->execute([$sid]);
$lastExam = $m->fetch();

$notices = $pdo->query("SELECT * FROM notices ORDER BY id DESC LIMIT 5")->fetchAll();

$pageTitle = 'Student Home';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head">
  <h1 class="page-title">Welcome, <?= e($me['full_name']) ?></h1>
  <span class="badge badge-info"><?= e($me['course_code']) ?> · Year <?= (int)$me['year'] ?> · Sec <?= e($me['section']) ?></span>
</div>

<div class="grid grid-4">
  <div class="stat <?= $attPct !== null && $attPct < 75 ? 'red' : 'green' ?>">
    <div class="num"><?= $attPct !== null ? $attPct . '%' : '—' ?></div>
    <div class="lbl">Overall Attendance<?= $attPct !== null && $attPct < 75 ? ' (below 75%!)' : '' ?></div>
  </div>
  <div class="stat gold"><div class="num"><?= money($balance) ?></div><div class="lbl">Fee Balance (<?= e(CURRENT_ACADEMIC_YEAR) ?>)</div></div>
  <div class="stat"><div class="num"><?= $lastExam ? round($lastExam['pct'], 1) . '%' : '—' ?></div>
    <div class="lbl"><?= $lastExam ? e($lastExam['name']) : 'No exam results yet' ?></div></div>
  <div class="stat"><div class="num"><?= e($me['admission_no']) ?></div><div class="lbl">Admission Number</div></div>
</div>

<div class="grid grid-2" style="margin-top:20px">
  <div class="card">
    <h2>Quick Links</h2>
    <p style="display:flex;gap:10px;flex-wrap:wrap">
      <a class="btn btn-primary" href="attendance.php">My Attendance</a>
      <a class="btn btn-primary" href="fees.php">My Fees</a>
      <a class="btn btn-primary" href="results.php">My Results</a>
      <a class="btn btn-gold" href="timetable.php">Class Timetable</a>
      <a class="btn btn-gold" href="profile.php">My Profile</a>
    </p>
    <h2 style="margin-top:20px">My Course</h2>
    <table>
      <tr><td>Course</td><td><b><?= e($me['course_name']) ?></b></td></tr>
      <tr><td>Year / Section</td><td><b>Year <?= (int)$me['year'] ?> — <?= e($me['section']) ?></b></td></tr>
      <tr><td>Status</td><td><span class="badge badge-ok"><?= e($me['status']) ?></span></td></tr>
    </table>
  </div>

  <div class="card">
    <h2>College Notices</h2>
    <?php if (!$notices): ?><p>No notices at the moment.</p><?php endif; ?>
    <?php foreach ($notices as $n): ?>
    <div class="notice">
      <h3><?= e($n['title']) ?></h3>
      <div class="meta"><?= e(date('d M Y', strtotime($n['created_at']))) ?></div>
      <p><?= nl2br(e($n['content'])) ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
