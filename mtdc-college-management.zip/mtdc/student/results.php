<?php
require_once __DIR__ . '/../includes/auth.php';
require_student();
$pdo = db();
$sid = (int)$_SESSION['student_id'];

$st = $pdo->prepare('SELECT s.*, c.name course_name FROM students s JOIN courses c ON c.id=s.course_id WHERE s.id=?');
$st->execute([$sid]);
$me = $st->fetch();

/* all exams where this student has marks */
$ex = $pdo->prepare("SELECT DISTINCT e.* FROM exams e JOIN marks m ON m.exam_id=e.id WHERE m.student_id=? ORDER BY e.id DESC");
$ex->execute([$sid]);
$myExams = $ex->fetchAll();

function grade(float $pct): array {
    if ($pct >= 75) return ['A', 'Distinction'];
    if ($pct >= 60) return ['B', 'First Class'];
    if ($pct >= 50) return ['C', 'Second Class'];
    if ($pct >= 35) return ['D', 'Pass'];
    return ['F', 'Fail'];
}

$pageTitle = 'My Results';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">My Results</h1></div>

<?php if (!$myExams): ?>
<div class="card"><p>No exam results have been published for you yet. Check back later.</p></div>
<?php endif; ?>

<?php foreach ($myExams as $exam):
    $mk = $pdo->prepare("SELECT m.*, sub.code, sub.name FROM marks m
        JOIN subjects sub ON sub.id=m.subject_id
        WHERE m.student_id=? AND m.exam_id=? ORDER BY sub.code");
    $mk->execute([$sid, $exam['id']]);
    $marks = $mk->fetchAll();
    $tot = array_sum(array_column($marks, 'marks_obtained'));
    $max = array_sum(array_column($marks, 'max_marks'));
    $pct = $max ? round($tot / $max * 100, 2) : 0;
    $anyFail = false;
    foreach ($marks as $m) if ($m['max_marks'] && ($m['marks_obtained'] / $m['max_marks'] * 100) < 35) $anyFail = true;
    [$g, $gname] = $anyFail ? ['F', 'Fail'] : grade($pct);
?>
<div class="card">
  <div class="page-head" style="margin-bottom:8px">
    <h2><?= e($exam['name']) ?> <small style="color:var(--muted)">(<?= e($exam['academic_year']) ?>)</small></h2>
    <span class="badge <?= $g === 'F' ? 'badge-err' : 'badge-ok' ?>">Grade <?= $g ?> — <?= $gname ?></span>
  </div>
  <div class="table-wrap"><table>
    <tr><th>Code</th><th>Subject</th><th class="num">Max</th><th class="num">Obtained</th><th class="num">%</th><th>Result</th></tr>
    <?php foreach ($marks as $m):
        $sp = $m['max_marks'] ? round($m['marks_obtained'] / $m['max_marks'] * 100, 1) : 0; ?>
    <tr>
      <td><b><?= e($m['code']) ?></b></td>
      <td><?= e($m['name']) ?></td>
      <td class="num"><?= (int)$m['max_marks'] ?></td>
      <td class="num"><?= e($m['marks_obtained'] + 0) ?></td>
      <td class="num"><?= $sp ?>%</td>
      <td><span class="badge <?= $sp >= 35 ? 'badge-ok' : 'badge-err' ?>"><?= $sp >= 35 ? 'Pass' : 'Fail' ?></span></td>
    </tr>
    <?php endforeach; ?>
    <tr><th colspan="2">Total</th><th class="num"><?= $max ?></th><th class="num"><?= $tot + 0 ?></th><th class="num"><?= $pct ?>%</th><th></th></tr>
  </table></div>
</div>
<?php endforeach; ?>

<?php if ($myExams): ?>
<p class="no-print"><button class="btn btn-gold" onclick="window.print()">🖨 Print Marks Memo</button></p>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
