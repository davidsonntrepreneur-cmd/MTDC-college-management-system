<?php
require_once __DIR__ . '/../includes/auth.php';
require_student();
csrf_verify();
$pdo = db();
$sid = (int)$_SESSION['student_id'];

/* ---------- UPDATE CONTACT DETAILS ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'contact') {
    $pdo->prepare('UPDATE students SET email=?, phone=?, address=?, guardian_phone=? WHERE id=?')
        ->execute([trim($_POST['email'] ?? '') ?: null, trim($_POST['phone'] ?? '') ?: null,
                   trim($_POST['address'] ?? '') ?: null, trim($_POST['guardian_phone'] ?? '') ?: null, $sid]);
    flash('success', 'Contact details updated.');
    header('Location: profile.php'); exit;
}

/* ---------- CHANGE PASSWORD ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'password') {
    $st = $pdo->prepare('SELECT password_hash FROM users WHERE id=?');
    $st->execute([$_SESSION['user_id']]);
    $hash = $st->fetchColumn();
    if (!password_verify($_POST['current'] ?? '', $hash)) {
        flash('error', 'Current password is incorrect.');
    } elseif (strlen($_POST['new'] ?? '') < 8) {
        flash('error', 'New password must be at least 8 characters.');
    } elseif (($_POST['new'] ?? '') !== ($_POST['confirm'] ?? '')) {
        flash('error', 'New passwords do not match.');
    } else {
        $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')
            ->execute([password_hash($_POST['new'], PASSWORD_BCRYPT), $_SESSION['user_id']]);
        flash('success', 'Password changed successfully.');
    }
    header('Location: profile.php'); exit;
}

$st = $pdo->prepare('SELECT s.*, c.name course_name FROM students s JOIN courses c ON c.id=s.course_id WHERE s.id=?');
$st->execute([$sid]);
$me = $st->fetch();

$pageTitle = 'My Profile';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">My Profile</h1></div>

<div class="grid grid-2">
  <div class="card">
    <h2>Student Details</h2>
    <table>
      <tr><td>Admission No</td><td><b><?= e($me['admission_no']) ?></b></td></tr>
      <tr><td>Full Name</td><td><b><?= e($me['full_name']) ?></b></td></tr>
      <tr><td>Course</td><td><?= e($me['course_name']) ?></td></tr>
      <tr><td>Year / Section</td><td>Year <?= (int)$me['year'] ?> — <?= e($me['section']) ?></td></tr>
      <tr><td>Date of Birth</td><td><?= $me['dob'] ? e(date('d-m-Y', strtotime($me['dob']))) : '—' ?></td></tr>
      <tr><td>Gender</td><td><?= e($me['gender']) ?></td></tr>
      <tr><td>Guardian</td><td><?= e($me['guardian_name'] ?: '—') ?></td></tr>
      <tr><td>Admission Date</td><td><?= $me['admission_date'] ? e(date('d-m-Y', strtotime($me['admission_date']))) : '—' ?></td></tr>
    </table>
    <p style="font-size:12.5px;color:var(--muted);margin-top:10px">To correct name, DOB or course details, contact the college office.</p>
  </div>

  <div>
    <div class="card">
      <h2>Update Contact Details</h2>
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="do" value="contact">
        <div class="form-row">
          <div><label>Email</label><input type="email" name="email" value="<?= e($me['email']) ?>"></div>
          <div><label>Phone</label><input name="phone" value="<?= e($me['phone']) ?>"></div>
          <div><label>Guardian Phone</label><input name="guardian_phone" value="<?= e($me['guardian_phone']) ?>"></div>
        </div>
        <label>Address</label><textarea name="address" rows="2"><?= e($me['address']) ?></textarea>
        <p style="margin-top:12px"><button class="btn btn-primary">Save</button></p>
      </form>
    </div>

    <div class="card">
      <h2>Change Password</h2>
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="do" value="password">
        <label>Current Password</label><input type="password" name="current" required>
        <label>New Password (min 8 chars)</label><input type="password" name="new" required minlength="8">
        <label>Confirm New Password</label><input type="password" name="confirm" required>
        <p style="margin-top:12px"><button class="btn btn-primary">Change Password</button></p>
      </form>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
