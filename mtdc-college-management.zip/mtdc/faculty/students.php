<?php
require_once __DIR__ . '/../includes/auth.php';
require_faculty();
$pdo = db();
$fid = (int)$_SESSION['faculty_id'];

$cls = $pdo->prepare('SELECT fc.*, c.name course_name, c.code course_code
    FROM faculty_classes fc JOIN courses c ON c.id=fc.course_id WHERE fc.faculty_id=? ORDER BY c.code, fc.year');
$cls->execute([$fid]);
$classes = $cls->fetchAll();
$classById = array_column($classes, null, 'id');

$selClass = (int)($_GET['class'] ?? ($classes[0]['id'] ?? 0));
$cl = $classById[$selClass] ?? null;

$students = [];
if ($cl) {
    $st = $pdo->prepare("SELECT s.*,
        (SELECT COUNT(*) FROM attendance a WHERE a.student_id=s.id) att_total,
        (SELECT COUNT(*) FROM attendance a WHERE a.student_id=s.id AND a.status='Present') att_present
        FROM students s
        WHERE s.course_id=? AND s.year=? AND s.section=? AND s.status='Active'
        ORDER BY s.admission_no");
    $st->execute([$cl['course_id'], $cl['year'], $cl['section']]);
    $students = $st->fetchAll();
}

$pageTitle = 'My Students';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">My Students</h1></div>

<div class="card">
  <form class="inline-form" method="get">
    <div><label>Class</label>
      <select name="class" onchange="this.form.submit()">
        <?php foreach ($classes as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $selClass == $c['id'] ? 'selected' : '' ?>>
          <?= e($c['course_code'] . ' · Year ' . $c['year'] . ' · Sec ' . $c['section']) ?></option>
        <?php endforeach; ?>
      </select></div>
  </form>
  <?php if (!$classes): ?><p style="margin-top:10px;color:var(--err)">No classes assigned to you yet.</p><?php endif; ?>
</div>

<?php if ($cl): ?>
<div class="card">
  <h2><?= e($cl['course_name']) ?> — Year <?= (int)$cl['year'] ?>, Sec <?= e($cl['section']) ?> (<?= count($students) ?> students)</h2>
  <div class="table-wrap"><table>
    <tr><th>Adm. No</th><th>Name</th><th>Phone</th><th>Guardian</th><th>Guardian Phone</th><th class="num">Attendance %</th></tr>
    <?php if (!$students): ?><tr><td colspan="6">No active students in this class.</td></tr><?php endif; ?>
    <?php foreach ($students as $s):
        $pct = $s['att_total'] ? round($s['att_present'] / $s['att_total'] * 100, 1) : null; ?>
    <tr>
      <td><b><?= e($s['admission_no']) ?></b></td>
      <td><?= e($s['full_name']) ?></td>
      <td><?= e($s['phone']) ?></td>
      <td><?= e($s['guardian_name']) ?></td>
      <td><?= e($s['guardian_phone']) ?></td>
      <td class="num"><?php if ($pct === null): ?>—<?php else: ?>
        <span class="badge <?= $pct >= 75 ? 'badge-ok' : 'badge-err' ?>"><?= $pct ?>%</span><?php endif; ?></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
