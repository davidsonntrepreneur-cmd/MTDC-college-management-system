<?php
require_once __DIR__ . '/../includes/auth.php';
require_faculty();
csrf_verify();
$pdo = db();
$fid = (int)$_SESSION['faculty_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'contact') {
    $pdo->prepare('UPDATE faculty SET email=?, phone=? WHERE id=?')
        ->execute([trim($_POST['email'] ?? '') ?: null, trim($_POST['phone'] ?? '') ?: null, $fid]);
    flash('success', 'Contact details updated.');
    header('Location: profile.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'password') {
    $st = $pdo->prepare('SELECT password_hash FROM users WHERE id=?');
    $st->execute([$_SESSION['user_id']]);
    $hash = $st->fetchColumn();
    if (!password_verify($_POST['current'] ?? '', $hash)) {
        flash('error', 'Current password is incorrect.');
    } elseif (strlen($_POST['new'] ?? '') < 8) {
        flash('error', 'New password must be at least 8 characters.');
    } elseif (($_POST['new'] ?? '') !== ($_POST['confirm'] ?? '')) {
        flash('error', 'New passwords do not match.');
    } else {
        $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')
            ->execute([password_hash($_POST['new'], PASSWORD_BCRYPT), $_SESSION['user_id']]);
        flash('success', 'Password changed successfully.');
    }
    header('Location: profile.php'); exit;
}

$me = $pdo->prepare('SELECT * FROM faculty WHERE id=?');
$me->execute([$fid]);
$me = $me->fetch();

$pageTitle = 'My Profile';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">My Profile</h1></div>

<div class="grid grid-2">
  <div class="card">
    <h2>Faculty Details</h2>
    <table>
      <tr><td>Employee No</td><td><b><?= e($me['emp_no']) ?></b></td></tr>
      <tr><td>Full Name</td><td><b><?= e($me['full_name']) ?></b></td></tr>
      <tr><td>Designation</td><td><?= e($me['designation']) ?></td></tr>
      <tr><td>Department</td><td><?= e($me['department'] ?: '—') ?></td></tr>
      <tr><td>Status</td><td><span class="badge badge-ok"><?= e($me['status']) ?></span></td></tr>
    </table>
  </div>

  <div>
    <div class="card">
      <h2>Update Contact Details</h2>
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="do" value="contact">
        <div class="form-row">
          <div><label>Email</label><input type="email" name="email" value="<?= e($me['email']) ?>"></div>
          <div><label>Phone</label><input name="phone" value="<?= e($me['phone']) ?>"></div>
        </div>
        <p style="margin-top:12px"><button class="btn btn-primary">Save</button></p>
      </form>
    </div>

    <div class="card">
      <h2>Change Password</h2>
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="do" value="password">
        <label>Current Password</label><input type="password" name="current" required>
        <label>New Password (min 8 chars)</label><input type="password" name="new" required minlength="8">
        <label>Confirm New Password</label><input type="password" name="confirm" required>
        <p style="margin-top:12px"><button class="btn btn-primary">Change Password</button></p>
      </form>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
