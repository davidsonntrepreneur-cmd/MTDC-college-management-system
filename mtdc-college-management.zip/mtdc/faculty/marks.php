<?php
require_once __DIR__ . '/../includes/auth.php';
require_faculty();
csrf_verify();
$pdo = db();
$fid = (int)$_SESSION['faculty_id'];

$cls = $pdo->prepare('SELECT fc.*, c.name course_name, c.code course_code
    FROM faculty_classes fc JOIN courses c ON c.id=fc.course_id WHERE fc.faculty_id=? ORDER BY c.code, fc.year');
$cls->execute([$fid]);
$classes = $cls->fetchAll();
$classById = array_column($classes, null, 'id');
$exams = $pdo->query('SELECT * FROM exams ORDER BY id DESC')->fetchAll();

/* ---------- SAVE MARKS ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'save_marks') {
    $cl = $classById[(int)$_POST['class']] ?? null;
    if (!$cl) { http_response_code(403); die('That class is not assigned to you.'); }
    $examId = (int)$_POST['exam_id'];
    $subId  = (int)$_POST['subject_id'];
    /* subject must belong to the class's course/year */
    $chk = $pdo->prepare('SELECT max_marks FROM subjects WHERE id=? AND course_id=? AND year=?');
    $chk->execute([$subId, $cl['course_id'], $cl['year']]);
    $max = $chk->fetchColumn();
    if ($max === false) { http_response_code(403); die('Invalid subject for this class.'); }
    $max = (int)$max ?: 100;

    $valid = $pdo->prepare("SELECT id FROM students WHERE course_id=? AND year=? AND section=? AND status='Active'");
    $valid->execute([$cl['course_id'], $cl['year'], $cl['section']]);
    $validIds = array_column($valid->fetchAll(), 'id');

    $stmt = $pdo->prepare('INSERT INTO marks (exam_id, student_id, subject_id, marks_obtained, max_marks)
                           VALUES (?,?,?,?,?)
                           ON DUPLICATE KEY UPDATE marks_obtained = VALUES(marks_obtained), max_marks = VALUES(max_marks)');
    $n = 0;
    foreach (($_POST['marks'] ?? []) as $sid => $m) {
        if ($m === '' || !in_array((int)$sid, $validIds)) continue;
        $stmt->execute([$examId, (int)$sid, $subId, max(0, min((float)$m, $max)), $max]);
        $n++;
    }
    flash('success', "Marks saved for $n students.");
    header('Location: marks.php?class=' . (int)$_POST['class'] . '&exam=' . $examId . '&subject=' . $subId); exit;
}

/* ---------- SELECTION ---------- */
$selClass   = (int)($_GET['class'] ?? 0);
$selExam    = (int)($_GET['exam'] ?? 0);
$selSubject = (int)($_GET['subject'] ?? 0);
$cl = $classById[$selClass] ?? null;

$subjects = [];
if ($cl) {
    $st = $pdo->prepare('SELECT * FROM subjects WHERE course_id=? AND year=? ORDER BY semester, code');
    $st->execute([$cl['course_id'], $cl['year']]);
    $subjects = $st->fetchAll();
}

$entryRows = [];
if ($cl && $selExam && $selSubject) {
    $st = $pdo->prepare("SELECT s.id, s.admission_no, s.full_name, m.marks_obtained
        FROM students s
        LEFT JOIN marks m ON m.student_id=s.id AND m.exam_id=? AND m.subject_id=?
        WHERE s.course_id=? AND s.year=? AND s.section=? AND s.status='Active'
        ORDER BY s.admission_no");
    $st->execute([$selExam, $selSubject, $cl['course_id'], $cl['year'], $cl['section']]);
    $entryRows = $st->fetchAll();
}

$pageTitle = 'Marks Entry';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">Marks Entry</h1></div>

<div class="card">
  <form class="inline-form" method="get">
    <div><label>Class</label>
      <select name="class" required onchange="this.form.submit()">
        <option value="">— Class —</option>
        <?php foreach ($classes as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $selClass == $c['id'] ? 'selected' : '' ?>>
          <?= e($c['course_code'] . ' · Y' . $c['year'] . ' · ' . $c['section']) ?></option>
        <?php endforeach; ?>
      </select></div>
    <div><label>Exam</label>
      <select name="exam" required>
        <option value="">— Exam —</option>
        <?php foreach ($exams as $ex): ?>
        <option value="<?= $ex['id'] ?>" <?= $selExam == $ex['id'] ? 'selected' : '' ?>><?= e($ex['name'] . ' (' . $ex['academic_year'] . ')') ?></option>
        <?php endforeach; ?>
      </select></div>
    <div><label>Subject</label>
      <select name="subject"><option value="">— Subject —</option>
        <?php foreach ($subjects as $sub): ?>
        <option value="<?= $sub['id'] ?>" <?= $selSubject == $sub['id'] ? 'selected' : '' ?>><?= e('Sem ' . $sub['semester'] . ' · ' . $sub['code'] . ' ' . $sub['name']) ?></option>
        <?php endforeach; ?>
      </select></div>
    <button class="btn btn-primary btn-sm">Load</button>
  </form>
  <?php if (!$classes): ?><p style="margin-top:10px;color:var(--err)">No classes assigned to you yet.</p>
  <?php elseif ($cl && !$subjects): ?><p style="margin-top:10px;color:var(--err)">No subjects defined for this course/year — ask the admin to add them.</p><?php endif; ?>
</div>

<?php if ($entryRows): ?>
<div class="card">
  <h2>Enter Marks — <?= e($cl['course_code']) ?> Year <?= (int)$cl['year'] ?> Sec <?= e($cl['section']) ?></h2>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="save_marks">
    <input type="hidden" name="class" value="<?= $selClass ?>">
    <input type="hidden" name="exam_id" value="<?= $selExam ?>">
    <input type="hidden" name="subject_id" value="<?= $selSubject ?>">
    <div class="table-wrap"><table>
      <tr><th>#</th><th>Adm. No</th><th>Name</th><th style="width:160px">Marks Obtained</th></tr>
      <?php foreach ($entryRows as $i => $r): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><b><?= e($r['admission_no']) ?></b></td>
        <td><?= e($r['full_name']) ?></td>
        <td><input type="number" step="0.5" min="0" name="marks[<?= $r['id'] ?>]" value="<?= $r['marks_obtained'] !== null ? e($r['marks_obtained']) : '' ?>" placeholder="—"></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
    <p style="margin-top:14px"><button class="btn btn-primary">Save Marks</button>
    <span style="font-size:12.5px;color:var(--muted)">Leave blank to skip. Values above max marks are capped.</span></p>
  </form>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
