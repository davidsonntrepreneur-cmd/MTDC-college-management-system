<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notify.php';
require_faculty();
csrf_verify();
$pdo = db();
$fid = (int)$_SESSION['faculty_id'];

/* faculty's assigned classes */
$cls = $pdo->prepare('SELECT fc.*, c.name course_name, c.code course_code
    FROM faculty_classes fc JOIN courses c ON c.id=fc.course_id WHERE fc.faculty_id=? ORDER BY c.code, fc.year');
$cls->execute([$fid]);
$classes = $cls->fetchAll();
$classById = array_column($classes, null, 'id');

/* helper: verify the class belongs to this faculty */
function my_class(array $classById, int $id): ?array { return $classById[$id] ?? null; }

/* ---------- SAVE ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'mark') {
    $cl = my_class($classById, (int)$_POST['class']);
    if (!$cl) { http_response_code(403); die('That class is not assigned to you.'); }
    $date = $_POST['att_date'] ?: date('Y-m-d');
    $stmt = $pdo->prepare('INSERT INTO attendance (student_id, att_date, status, marked_by)
                           VALUES (?,?,?,?)
                           ON DUPLICATE KEY UPDATE status = VALUES(status), marked_by = VALUES(marked_by)');
    // only accept students who really belong to this class
    $valid = $pdo->prepare("SELECT id FROM students WHERE course_id=? AND year=? AND section=? AND status='Active'");
    $valid->execute([$cl['course_id'], $cl['year'], $cl['section']]);
    $validIds = array_column($valid->fetchAll(), 'id');
    $n = 0; $absentIds = [];
    foreach (($_POST['status'] ?? []) as $sid => $stv) {
        if (in_array((int)$sid, $validIds) && in_array($stv, ['Present', 'Absent'])) {
            $stmt->execute([(int)$sid, $date, $stv, $_SESSION['user_id']]);
            if ($stv === 'Absent') $absentIds[] = (int)$sid;
            $n++;
        }
    }
    /* notify guardians of absentees (no-op unless enabled in config) */
    if ($absentIds && (SMS_ENABLED || MAIL_ENABLED)) {
        $in = implode(',', array_fill(0, count($absentIds), '?'));
        $q = $pdo->prepare("SELECT full_name, email, phone, guardian_phone FROM students WHERE id IN ($in)");
        $q->execute($absentIds);
        foreach ($q->fetchAll() as $s) {
            $msg = "Dear Parent, your ward {$s['full_name']} was ABSENT at " . COLLEGE_NAME . " on " . date('d-m-Y', strtotime($date)) . ". - " . SMS_SENDER;
            send_sms($s['guardian_phone'] ?: $s['phone'], $msg);
            send_email($s['email'], 'Absence noted - ' . date('d-m-Y', strtotime($date)), $msg);
        }
    }
    flash('success', "Attendance saved for $n students on " . date('d-m-Y', strtotime($date)) . '.');
    header('Location: attendance.php?class=' . (int)$_POST['class'] . '&date=' . $date); exit;
}

/* ---------- SELECTION ---------- */
$selClass = (int)($_GET['class'] ?? 0);
$selDate  = $_GET['date'] ?? date('Y-m-d');
$cl = my_class($classById, $selClass);

$students = [];
if ($cl) {
    $st = $pdo->prepare("SELECT s.*, a.status att_status
        FROM students s
        LEFT JOIN attendance a ON a.student_id = s.id AND a.att_date = ?
        WHERE s.course_id = ? AND s.year = ? AND s.section = ? AND s.status='Active'
        ORDER BY s.admission_no");
    $st->execute([$selDate, $cl['course_id'], $cl['year'], $cl['section']]);
    $students = $st->fetchAll();
}

$pageTitle = 'Attendance';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">Mark Attendance</h1></div>

<div class="card">
  <form class="inline-form" method="get">
    <div><label>Class</label>
      <select name="class" required>
        <option value="">— Select class —</option>
        <?php foreach ($classes as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $selClass == $c['id'] ? 'selected' : '' ?>>
          <?= e($c['course_code'] . ' · Year ' . $c['year'] . ' · Sec ' . $c['section']) ?></option>
        <?php endforeach; ?>
      </select></div>
    <div><label>Date</label><input type="date" name="date" value="<?= e($selDate) ?>" max="<?= date('Y-m-d') ?>"></div>
    <button class="btn btn-primary btn-sm">Load Students</button>
  </form>
  <?php if (!$classes): ?><p style="margin-top:10px;color:var(--err)">No classes assigned to you yet — contact the administrator.</p><?php endif; ?>
</div>

<?php if ($cl && $students): ?>
<div class="card">
  <h2><?= e($cl['course_name']) ?> — Year <?= (int)$cl['year'] ?>, Sec <?= e($cl['section']) ?> · <?= e(date('d-m-Y', strtotime($selDate))) ?></h2>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="mark">
    <input type="hidden" name="class" value="<?= $selClass ?>">
    <input type="hidden" name="att_date" value="<?= e($selDate) ?>">
    <p class="no-print" style="margin-bottom:10px">
      <button type="button" class="btn btn-sm btn-gold" onclick="setAll('Present')">All Present</button>
      <button type="button" class="btn btn-sm btn-danger" onclick="setAll('Absent')">All Absent</button>
    </p>
    <div class="table-wrap"><table>
      <tr><th>#</th><th>Adm. No</th><th>Name</th><th>Status</th></tr>
      <?php foreach ($students as $i => $s): $cur = $s['att_status'] ?? 'Present'; ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><b><?= e($s['admission_no']) ?></b></td>
        <td><?= e($s['full_name']) ?></td>
        <td class="att-row">
          <label><input type="radio" name="status[<?= $s['id'] ?>]" value="Present" <?= $cur === 'Present' ? 'checked' : '' ?>> Present</label>
          <label><input type="radio" name="status[<?= $s['id'] ?>]" value="Absent" <?= $cur === 'Absent' ? 'checked' : '' ?>> Absent</label>
        </td>
      </tr>
      <?php endforeach; ?>
    </table></div>
    <p style="margin-top:14px"><button class="btn btn-primary">Save Attendance</button></p>
  </form>
</div>
<script>
function setAll(v) { document.querySelectorAll('input[type=radio][value=' + v + ']').forEach(r => r.checked = true); }
</script>
<?php elseif ($cl): ?>
<div class="card"><p>No active students in this class yet.</p></div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
