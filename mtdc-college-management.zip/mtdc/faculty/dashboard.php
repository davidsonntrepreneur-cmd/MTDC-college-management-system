<?php
require_once __DIR__ . '/../includes/auth.php';
require_faculty();
$pdo = db();
$fid = (int)$_SESSION['faculty_id'];

$me = $pdo->prepare('SELECT * FROM faculty WHERE id=?');
$me->execute([$fid]);
$me = $me->fetch();

$classes = $pdo->prepare('SELECT fc.*, c.name course_name, c.code course_code,
    (SELECT COUNT(*) FROM students s WHERE s.course_id=fc.course_id AND s.year=fc.year AND s.section=fc.section AND s.status=\'Active\') cnt
    FROM faculty_classes fc JOIN courses c ON c.id=fc.course_id WHERE fc.faculty_id=? ORDER BY c.code, fc.year');
$classes->execute([$fid]);
$classes = $classes->fetchAll();
$totalStudents = array_sum(array_column($classes, 'cnt'));

/* today's attendance status per class */
$today = date('Y-m-d');
$attQ = $pdo->prepare("SELECT COUNT(*) FROM attendance a JOIN students s ON s.id=a.student_id
    WHERE a.att_date=? AND s.course_id=? AND s.year=? AND s.section=?");

$notices = $pdo->query("SELECT * FROM notices ORDER BY id DESC LIMIT 4")->fetchAll();

$pageTitle = 'Faculty Home';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head">
  <h1 class="page-title">Welcome, <?= e($me['full_name']) ?></h1>
  <span class="badge badge-info"><?= e($me['designation']) ?><?= $me['department'] ? ' · ' . e($me['department']) : '' ?></span>
</div>

<div class="grid grid-4">
  <div class="stat"><div class="num"><?= count($classes) ?></div><div class="lbl">Assigned Classes</div></div>
  <div class="stat gold"><div class="num"><?= $totalStudents ?></div><div class="lbl">Total Students</div></div>
  <div class="stat green"><div class="num"><?= e(date('d M')) ?></div><div class="lbl"><?= e(date('l')) ?></div></div>
  <div class="stat"><div class="num"><?= e($me['emp_no']) ?></div><div class="lbl">Employee No</div></div>
</div>

<div class="grid grid-2" style="margin-top:20px">
  <div class="card">
    <h2>My Classes</h2>
    <?php if (!$classes): ?>
    <p>No classes have been assigned to you yet. Please contact the administrator.</p>
    <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Class</th><th class="num">Students</th><th>Attendance Today</th><th></th></tr>
      <?php foreach ($classes as $c):
          $attQ->execute([$today, $c['course_id'], $c['year'], $c['section']]);
          $marked = (int)$attQ->fetchColumn(); ?>
      <tr>
        <td><b><?= e($c['course_code']) ?></b> · Year <?= (int)$c['year'] ?> · Sec <?= e($c['section']) ?></td>
        <td class="num"><?= (int)$c['cnt'] ?></td>
        <td><?php if (!$c['cnt']): ?><span class="badge badge-warn">No students</span>
            <?php elseif ($marked >= $c['cnt']): ?><span class="badge badge-ok">Marked</span>
            <?php elseif ($marked > 0): ?><span class="badge badge-warn">Partial (<?= $marked ?>/<?= $c['cnt'] ?>)</span>
            <?php else: ?><span class="badge badge-err">Not marked</span><?php endif; ?></td>
        <td><a class="btn btn-sm btn-primary" href="attendance.php?class=<?= $c['id'] ?>">Mark →</a></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
    <?php endif; ?>
    <p style="margin-top:12px">
      <a class="btn btn-sm btn-gold" href="marks.php">Enter Marks →</a>
      <a class="btn btn-sm btn-gold" href="students.php">View Students →</a>
    </p>
  </div>

  <div class="card">
    <h2>College Notices</h2>
    <?php if (!$notices): ?><p>No notices.</p><?php endif; ?>
    <?php foreach ($notices as $n): ?>
    <div class="notice">
      <h3><?= e($n['title']) ?></h3>
      <div class="meta"><?= e(date('d M Y', strtotime($n['created_at']))) ?></div>
      <p><?= nl2br(e($n['content'])) ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
