-- =====================================================================
-- Mother Theresa Degree College, Palamaner
-- College Management System - Database Schema
-- Import: mysql -u root -p < schema.sql  (or via phpMyAdmin)
-- =====================================================================

CREATE DATABASE IF NOT EXISTS mtdc_cms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mtdc_cms;

-- ---------------------------------------------------------------------
-- Users (login accounts for admin + students)
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('admin','student','faculty') NOT NULL DEFAULT 'student',
  is_active     TINYINT(1)   NOT NULL DEFAULT 1,
  last_login    DATETIME     NULL,
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Courses (degree programmes)
-- ---------------------------------------------------------------------
CREATE TABLE courses (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  code           VARCHAR(20) NOT NULL UNIQUE,
  name           VARCHAR(100) NOT NULL,
  duration_years TINYINT NOT NULL DEFAULT 3
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Subjects (per course / year / semester)
-- ---------------------------------------------------------------------
CREATE TABLE subjects (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  year      TINYINT NOT NULL,            -- 1, 2, 3
  semester  TINYINT NOT NULL,            -- 1..6
  code      VARCHAR(20) NOT NULL,
  name      VARCHAR(120) NOT NULL,
  max_marks INT NOT NULL DEFAULT 100,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  UNIQUE KEY uq_subject (course_id, semester, code)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Students
-- ---------------------------------------------------------------------
CREATE TABLE students (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL UNIQUE,
  admission_no  VARCHAR(30) NOT NULL UNIQUE,
  full_name     VARCHAR(120) NOT NULL,
  email         VARCHAR(120),
  phone         VARCHAR(15),
  dob           DATE,
  gender        ENUM('Male','Female','Other') DEFAULT 'Male',
  address       VARCHAR(255),
  guardian_name VARCHAR(120),
  guardian_phone VARCHAR(15),
  course_id     INT NOT NULL,
  year          TINYINT NOT NULL DEFAULT 1,
  section       VARCHAR(5) NOT NULL DEFAULT 'A',
  admission_date DATE,
  status        ENUM('Active','Inactive','Passed Out') NOT NULL DEFAULT 'Active',
  FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Attendance (one row per student per date)
-- ---------------------------------------------------------------------
CREATE TABLE attendance (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  att_date   DATE NOT NULL,
  status     ENUM('Present','Absent') NOT NULL DEFAULT 'Present',
  marked_by  INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  UNIQUE KEY uq_att (student_id, att_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Fee structure (what each course/year must pay in an academic year)
-- ---------------------------------------------------------------------
CREATE TABLE fee_structure (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  course_id     INT NOT NULL,
  year          TINYINT NOT NULL,
  academic_year VARCHAR(9) NOT NULL,       -- e.g. 2026-27
  fee_type      VARCHAR(60) NOT NULL,      -- Tuition, Exam, Lab, ...
  amount        DECIMAL(10,2) NOT NULL,
  due_date      DATE NULL,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Fee payments (receipts)
-- ---------------------------------------------------------------------
CREATE TABLE fee_payments (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  receipt_no   VARCHAR(20) NOT NULL UNIQUE,
  student_id   INT NOT NULL,
  academic_year VARCHAR(9) NOT NULL,
  amount       DECIMAL(10,2) NOT NULL,
  payment_date DATE NOT NULL,
  mode         ENUM('Cash','UPI','Card','Bank Transfer','Cheque') NOT NULL DEFAULT 'Cash',
  remarks      VARCHAR(255),
  received_by  INT NULL,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Exams
-- ---------------------------------------------------------------------
CREATE TABLE exams (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,     -- e.g. Semester 1 Internal - I
  academic_year VARCHAR(9) NOT NULL,
  exam_date     DATE NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Marks / results
-- ---------------------------------------------------------------------
CREATE TABLE marks (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  exam_id        INT NOT NULL,
  student_id     INT NOT NULL,
  subject_id     INT NOT NULL,
  marks_obtained DECIMAL(6,2) NOT NULL,
  max_marks      INT NOT NULL DEFAULT 100,
  FOREIGN KEY (exam_id)    REFERENCES exams(id)    ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  UNIQUE KEY uq_mark (exam_id, student_id, subject_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Notices / announcements
-- ---------------------------------------------------------------------
CREATE TABLE notices (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  title      VARCHAR(150) NOT NULL,
  content    TEXT NOT NULL,
  audience   ENUM('All','Students') NOT NULL DEFAULT 'All',
  posted_by  INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Timetable
-- ---------------------------------------------------------------------
CREATE TABLE timetable (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  course_id   INT NOT NULL,
  year        TINYINT NOT NULL,
  section     VARCHAR(5) NOT NULL DEFAULT 'A',
  day_of_week TINYINT NOT NULL,            -- 1=Mon ... 6=Sat
  period_no   TINYINT NOT NULL,            -- 1..7
  subject_id  INT NULL,
  faculty     VARCHAR(100),
  start_time  TIME NOT NULL,
  end_time    TIME NOT NULL,
  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL,
  UNIQUE KEY uq_tt (course_id, year, section, day_of_week, period_no)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Faculty
-- ---------------------------------------------------------------------
CREATE TABLE faculty (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL UNIQUE,
  emp_no      VARCHAR(30) NOT NULL UNIQUE,
  full_name   VARCHAR(120) NOT NULL,
  email       VARCHAR(120),
  phone       VARCHAR(15),
  designation VARCHAR(80)  DEFAULT 'Lecturer',
  department  VARCHAR(80),
  status      ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Faculty class assignments (which classes a faculty member handles)
-- ---------------------------------------------------------------------
CREATE TABLE faculty_classes (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  faculty_id INT NOT NULL,
  course_id  INT NOT NULL,
  year       TINYINT NOT NULL,
  section    VARCHAR(5) NOT NULL DEFAULT 'A',
  FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id)  REFERENCES courses(id) ON DELETE CASCADE,
  UNIQUE KEY uq_fc (faculty_id, course_id, year, section)
) ENGINE=InnoDB;

-- =====================================================================
-- SEED DATA
-- =====================================================================

-- Default admin  ->  username: admin   password: admin@123
-- (CHANGE THIS PASSWORD after first login!)
INSERT INTO users (username, password_hash, role) VALUES
('admin', '$2y$12$u7fQ3on7WeQYcC83eTXTtOo1s9HO0Ycf2OFyW6DjA4aRt.rH01day', 'admin');

INSERT INTO courses (code, name, duration_years) VALUES
('BSC-MPC', 'B.Sc (Maths, Physics, Chemistry)', 3),
('BSC-MPCS','B.Sc (Maths, Physics, Computer Science)', 3),
('BCOM-GEN','B.Com (General)', 3),
('BCOM-CA', 'B.Com (Computer Applications)', 3),
('BA',      'B.A (History, Economics, Political Science)', 3),
('BCA',     'Bachelor of Computer Applications', 3);

-- A few sample subjects (B.Sc MPCs, Semester 1)
INSERT INTO subjects (course_id, year, semester, code, name, max_marks) VALUES
(2, 1, 1, 'ENG101',  'General English - I', 100),
(2, 1, 1, 'MAT101',  'Differential Equations', 100),
(2, 1, 1, 'PHY101',  'Mechanics & Properties of Matter', 100),
(2, 1, 1, 'CS101',   'Programming in C', 100),
(4, 1, 1, 'ENG101',  'General English - I', 100),
(4, 1, 1, 'ACC101',  'Financial Accounting - I', 100),
(4, 1, 1, 'BEC101',  'Business Economics', 100),
(4, 1, 1, 'ICT101',  'Fundamentals of IT', 100);

-- Sample fee structure (2026-27)
INSERT INTO fee_structure (course_id, year, academic_year, fee_type, amount, due_date) VALUES
(2, 1, '2026-27', 'Tuition Fee',    12500.00, '2026-08-31'),
(2, 1, '2026-27', 'Lab Fee',         1500.00, '2026-08-31'),
(2, 1, '2026-27', 'Exam Fee',         850.00, '2026-11-30'),
(4, 1, '2026-27', 'Tuition Fee',    11000.00, '2026-08-31'),
(4, 1, '2026-27', 'Computer Lab Fee', 1200.00, '2026-08-31'),
(4, 1, '2026-27', 'Exam Fee',         850.00, '2026-11-30');

-- Sample exam
INSERT INTO exams (name, academic_year, exam_date) VALUES
('Semester 1 - Internal Assessment I', '2026-27', '2026-09-15');

-- Welcome notice
INSERT INTO notices (title, content, audience) VALUES
('Welcome to MTDC Student Portal',
 'Dear students, welcome to the official student portal of Mother Theresa Degree College, Palamaner. Here you can view your attendance, fee details, exam results, class timetable and college notices. For login issues contact the college office.',
 'All');
