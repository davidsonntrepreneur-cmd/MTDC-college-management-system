-- =====================================================================
-- Upgrade script v1 -> v2 (faculty role + class assignments)
-- Run this ONLY on an existing installation. Fresh installs should
-- import schema.sql instead (it already contains everything).
-- =====================================================================
USE mtdc_cms;

ALTER TABLE users MODIFY role ENUM('admin','student','faculty') NOT NULL DEFAULT 'student';

CREATE TABLE IF NOT EXISTS faculty (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL UNIQUE,
  emp_no      VARCHAR(30) NOT NULL UNIQUE,
  full_name   VARCHAR(120) NOT NULL,
  email       VARCHAR(120),
  phone       VARCHAR(15),
  designation VARCHAR(80)  DEFAULT 'Lecturer',
  department  VARCHAR(80),
  status      ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS faculty_classes (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  faculty_id INT NOT NULL,
  course_id  INT NOT NULL,
  year       TINYINT NOT NULL,
  section    VARCHAR(5) NOT NULL DEFAULT 'A',
  FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id)  REFERENCES courses(id) ON DELETE CASCADE,
  UNIQUE KEY uq_fc (faculty_id, course_id, year, section)
) ENGINE=InnoDB;
