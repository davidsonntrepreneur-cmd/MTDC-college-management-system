<?php
/**
 * Database configuration — Mother Theresa Degree College CMS
 * Edit the four constants below to match your MySQL server.
 */
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'mtdc_cms');
define('DB_USER', 'root');
define('DB_PASS', '');           // XAMPP default is empty

define('COLLEGE_NAME', 'Mother Theresa Degree College');
define('COLLEGE_PLACE', 'Palamaner, Chittoor Dist., Andhra Pradesh');
define('CURRENT_ACADEMIC_YEAR', '2026-27');

/* ---------- Email notifications ----------
 * Set MAIL_ENABLED to true on a server where PHP mail() works
 * (most shared hosting) to email fee receipts, login credentials
 * and notices to students automatically. */
define('MAIL_ENABLED', false);
define('MAIL_FROM', 'no-reply@mtdcpalamaner.ac.in');
define('MAIL_FROM_NAME', COLLEGE_NAME);

/* ---------- SMS notifications (optional) ----------
 * Disabled by default. To enable, sign up with an SMS gateway
 * (e.g. Fast2SMS / MSG91), put your API key below and set
 * SMS_ENABLED to true. See includes/notify.php to adapt the
 * request format to your provider. */
define('SMS_ENABLED', false);
define('SMS_API_KEY', '');
define('SMS_SENDER', 'MTDCPL');

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            die('Database connection failed. Check config/db.php settings.');
        }
    }
    return $pdo;
}
