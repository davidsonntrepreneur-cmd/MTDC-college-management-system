<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
csrf_verify();
$pdo = db();
$courses = $pdo->query('SELECT * FROM courses ORDER BY name')->fetchAll();
$exams   = $pdo->query('SELECT * FROM exams ORDER BY id DESC')->fetchAll();

/* ---------- CREATE EXAM ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'exam_add') {
    $pdo->prepare('INSERT INTO exams (name, academic_year, exam_date) VALUES (?,?,?)')
        ->execute([trim($_POST['name']), $_POST['academic_year'] ?: CURRENT_ACADEMIC_YEAR, $_POST['exam_date'] ?: null]);
    flash('success', 'Exam created.');
    header('Location: results.php'); exit;
}

/* ---------- SAVE MARKS ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'save_marks') {
    $examId = (int)$_POST['exam_id'];
    $subId  = (int)$_POST['subject_id'];
    $maxQ = $pdo->prepare('SELECT max_marks FROM subjects WHERE id=?');
    $maxQ->execute([$subId]);
    $max = (int)($maxQ->fetchColumn() ?: 100);
    $stmt = $pdo->prepare('INSERT INTO marks (exam_id, student_id, subject_id, marks_obtained, max_marks)
                           VALUES (?,?,?,?,?)
                           ON DUPLICATE KEY UPDATE marks_obtained = VALUES(marks_obtained), max_marks = VALUES(max_marks)');
    $n = 0;
    foreach (($_POST['marks'] ?? []) as $sid => $m) {
        if ($m === '') continue;
        $m = max(0, min((float)$m, $max));
        $stmt->execute([$examId, (int)$sid, $subId, $m, $max]);
        $n++;
    }
    flash('success', "Marks saved for $n students.");
    header('Location: results.php?exam=' . $examId . '&course=' . (int)$_POST['course'] . '&year=' . (int)$_POST['year'] . '&subject=' . $subId); exit;
}

/* ---------- SELECTION ---------- */
$selExam    = (int)($_GET['exam'] ?? 0);
$selCourse  = (int)($_GET['course'] ?? 0);
$selYear    = (int)($_GET['year'] ?? 1);
$selSubject = (int)($_GET['subject'] ?? 0);

$subjects = [];
if ($selCourse) {
    $st = $pdo->prepare('SELECT * FROM subjects WHERE course_id=? AND year=? ORDER BY semester, code');
    $st->execute([$selCourse, $selYear]);
    $subjects = $st->fetchAll();
}

$entryRows = [];
if ($selExam && $selSubject) {
    $st = $pdo->prepare("SELECT s.id, s.admission_no, s.full_name, m.marks_obtained
        FROM students s
        LEFT JOIN marks m ON m.student_id=s.id AND m.exam_id=? AND m.subject_id=?
        WHERE s.course_id=? AND s.year=? AND s.status='Active'
        ORDER BY s.admission_no");
    $st->execute([$selExam, $selSubject, $selCourse, $selYear]);
    $entryRows = $st->fetchAll();
}

$pageTitle = 'Results';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">Results / Marks Entry</h1></div>

<div class="grid grid-2">
  <div class="card">
    <h2>Create Exam</h2>
    <form method="post">
      <?= csrf_field() ?><input type="hidden" name="do" value="exam_add">
      <div class="form-row">
        <div><label>Exam Name *</label><input name="name" required placeholder="Semester 1 Internal - I"></div>
        <div><label>Academic Year</label><input name="academic_year" value="<?= e(CURRENT_ACADEMIC_YEAR) ?>"></div>
        <div><label>Exam Date</label><input type="date" name="exam_date"></div>
      </div>
      <p style="margin-top:14px"><button class="btn btn-gold">Create Exam</button></p>
    </form>
  </div>

  <div class="card">
    <h2>Select Class &amp; Subject for Marks Entry</h2>
    <form class="inline-form" method="get">
      <div><label>Exam</label>
        <select name="exam" required><option value="">— Exam —</option>
          <?php foreach ($exams as $ex): ?>
          <option value="<?= $ex['id'] ?>" <?= $selExam == $ex['id'] ? 'selected' : '' ?>><?= e($ex['name'] . ' (' . $ex['academic_year'] . ')') ?></option>
          <?php endforeach; ?>
        </select></div>
      <div><label>Course</label>
        <select name="course" required onchange="this.form.submit()"><option value="">— Course —</option>
          <?php foreach ($courses as $c): ?>
          <option value="<?= $c['id'] ?>" <?= $selCourse == $c['id'] ? 'selected' : '' ?>><?= e($c['code']) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div><label>Year</label>
        <select name="year" onchange="this.form.submit()"><?php for ($y=1;$y<=3;$y++): ?>
          <option value="<?= $y ?>" <?= $selYear == $y ? 'selected' : '' ?>>Year <?= $y ?></option><?php endfor; ?></select></div>
      <div><label>Subject</label>
        <select name="subject"><option value="">— Subject —</option>
          <?php foreach ($subjects as $sub): ?>
          <option value="<?= $sub['id'] ?>" <?= $selSubject == $sub['id'] ? 'selected' : '' ?>><?= e('Sem ' . $sub['semester'] . ' · ' . $sub['code'] . ' ' . $sub['name']) ?></option>
          <?php endforeach; ?>
        </select></div>
      <button class="btn btn-primary btn-sm">Load</button>
    </form>
    <?php if ($selCourse && !$subjects): ?><p style="margin-top:10px;color:var(--err)">No subjects defined for this course/year. Add them in the <a href="subjects.php">Subjects</a> page.</p><?php endif; ?>
  </div>
</div>

<?php if ($entryRows): ?>
<div class="card">
  <h2>Enter Marks</h2>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="save_marks">
    <input type="hidden" name="exam_id" value="<?= $selExam ?>">
    <input type="hidden" name="subject_id" value="<?= $selSubject ?>">
    <input type="hidden" name="course" value="<?= $selCourse ?>">
    <input type="hidden" name="year" value="<?= $selYear ?>">
    <div class="table-wrap"><table>
      <tr><th>#</th><th>Adm. No</th><th>Name</th><th style="width:160px">Marks Obtained</th></tr>
      <?php foreach ($entryRows as $i => $r): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><b><?= e($r['admission_no']) ?></b></td>
        <td><?= e($r['full_name']) ?></td>
        <td><input type="number" step="0.5" min="0" name="marks[<?= $r['id'] ?>]" value="<?= $r['marks_obtained'] !== null ? e($r['marks_obtained']) : '' ?>" placeholder="—"></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
    <p style="margin-top:14px"><button class="btn btn-primary">Save Marks</button>
    <span style="font-size:12.5px;color:var(--muted)">Leave blank to skip a student. Values above max marks are capped automatically.</span></p>
  </form>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
