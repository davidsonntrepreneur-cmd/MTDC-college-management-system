<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
csrf_verify();
$pdo = db();
$courses = $pdo->query('SELECT * FROM courses ORDER BY name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'add') {
    try {
        $pdo->prepare('INSERT INTO subjects (course_id, year, semester, code, name, max_marks) VALUES (?,?,?,?,?,?)')
            ->execute([(int)$_POST['course_id'], (int)$_POST['year'], (int)$_POST['semester'],
                       strtoupper(trim($_POST['code'])), trim($_POST['name']), (int)($_POST['max_marks'] ?: 100)]);
        flash('success', 'Subject added.');
    } catch (PDOException $e) {
        flash('error', 'Could not add subject (duplicate code for that course/semester?).');
    }
    header('Location: subjects.php'); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'del') {
    $pdo->prepare('DELETE FROM subjects WHERE id=?')->execute([(int)$_POST['id']]);
    flash('success', 'Subject deleted.');
    header('Location: subjects.php'); exit;
}

$fCourse = (int)($_GET['course'] ?? 0);
$sql = 'SELECT sub.*, c.code course_code FROM subjects sub JOIN courses c ON c.id=sub.course_id';
$args = [];
if ($fCourse) { $sql .= ' WHERE sub.course_id=?'; $args[] = $fCourse; }
$sql .= ' ORDER BY c.code, sub.year, sub.semester, sub.code';
$st = $pdo->prepare($sql); $st->execute($args);
$subjects = $st->fetchAll();

$pageTitle = 'Subjects';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">Subjects</h1></div>

<div class="card">
  <h2>Add Subject</h2>
  <form method="post">
    <?= csrf_field() ?><input type="hidden" name="do" value="add">
    <div class="form-row">
      <div><label>Course</label>
        <select name="course_id"><?php foreach ($courses as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
      <div><label>Year</label>
        <select name="year"><?php for ($y=1;$y<=3;$y++): ?><option value="<?= $y ?>">Year <?= $y ?></option><?php endfor; ?></select></div>
      <div><label>Semester</label>
        <select name="semester"><?php for ($s=1;$s<=6;$s++): ?><option value="<?= $s ?>">Sem <?= $s ?></option><?php endfor; ?></select></div>
      <div><label>Subject Code *</label><input name="code" required placeholder="MAT101"></div>
      <div><label>Subject Name *</label><input name="name" required placeholder="Differential Equations"></div>
      <div><label>Max Marks</label><input type="number" name="max_marks" value="100" min="1"></div>
    </div>
    <p style="margin-top:14px"><button class="btn btn-primary">Add Subject</button></p>
  </form>
</div>

<div class="card">
  <form class="inline-form" method="get" style="margin-bottom:12px">
    <div><label>Filter by Course</label>
      <select name="course" onchange="this.form.submit()"><option value="0">All courses</option>
        <?php foreach ($courses as $c): ?><option value="<?= $c['id'] ?>" <?= $fCourse == $c['id'] ? 'selected' : '' ?>><?= e($c['code']) ?></option><?php endforeach; ?>
      </select></div>
  </form>
  <div class="table-wrap"><table>
    <tr><th>Course</th><th>Year</th><th>Sem</th><th>Code</th><th>Subject</th><th class="num">Max Marks</th><th></th></tr>
    <?php foreach ($subjects as $s): ?>
    <tr>
      <td><?= e($s['course_code']) ?></td><td><?= (int)$s['year'] ?></td><td><?= (int)$s['semester'] ?></td>
      <td><b><?= e($s['code']) ?></b></td><td><?= e($s['name']) ?></td><td class="num"><?= (int)$s['max_marks'] ?></td>
      <td><form method="post" onsubmit="return confirm('Delete subject? Marks for it will also be deleted.')"><?= csrf_field() ?>
        <input type="hidden" name="do" value="del"><input type="hidden" name="id" value="<?= $s['id'] ?>">
        <button class="btn btn-sm btn-danger">✕</button></form></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
