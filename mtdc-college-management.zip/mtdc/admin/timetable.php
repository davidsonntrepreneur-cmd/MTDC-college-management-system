<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
csrf_verify();
$pdo = db();
$courses = $pdo->query('SELECT * FROM courses ORDER BY name')->fetchAll();
$days = [1=>'Monday',2=>'Tuesday',3=>'Wednesday',4=>'Thursday',5=>'Friday',6=>'Saturday'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'add') {
    try {
        $pdo->prepare('INSERT INTO timetable (course_id, year, section, day_of_week, period_no, subject_id, faculty, start_time, end_time)
                       VALUES (?,?,?,?,?,?,?,?,?)
                       ON DUPLICATE KEY UPDATE subject_id=VALUES(subject_id), faculty=VALUES(faculty), start_time=VALUES(start_time), end_time=VALUES(end_time)')
            ->execute([(int)$_POST['course_id'], (int)$_POST['year'], trim($_POST['section'] ?: 'A'),
                       (int)$_POST['day_of_week'], (int)$_POST['period_no'],
                       (int)$_POST['subject_id'] ?: null, trim($_POST['faculty'] ?? '') ?: null,
                       $_POST['start_time'], $_POST['end_time']]);
        flash('success', 'Timetable slot saved.');
    } catch (PDOException $e) { flash('error', 'Could not save slot.'); }
    header('Location: timetable.php?course=' . (int)$_POST['course_id'] . '&year=' . (int)$_POST['year'] . '&section=' . urlencode($_POST['section'] ?: 'A')); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'del') {
    $pdo->prepare('DELETE FROM timetable WHERE id=?')->execute([(int)$_POST['id']]);
    flash('success', 'Slot removed.');
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'timetable.php')); exit;
}

$selCourse  = (int)($_GET['course'] ?? 0);
$selYear    = (int)($_GET['year'] ?? 1);
$selSection = trim($_GET['section'] ?? 'A');

$subjects = [];
if ($selCourse) {
    $st = $pdo->prepare('SELECT * FROM subjects WHERE course_id=? AND year=? ORDER BY code');
    $st->execute([$selCourse, $selYear]);
    $subjects = $st->fetchAll();
}

$slots = [];
if ($selCourse) {
    $st = $pdo->prepare('SELECT t.*, s.code sub_code, s.name sub_name FROM timetable t
        LEFT JOIN subjects s ON s.id=t.subject_id
        WHERE t.course_id=? AND t.year=? AND t.section=?');
    $st->execute([$selCourse, $selYear, $selSection]);
    foreach ($st->fetchAll() as $row) { $slots[$row['day_of_week']][$row['period_no']] = $row; }
}
$maxPeriod = 7;

$pageTitle = 'Timetable';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">Timetable Management</h1></div>

<div class="card">
  <form class="inline-form" method="get">
    <div><label>Course</label>
      <select name="course" required><option value="">— Select —</option>
        <?php foreach ($courses as $c): ?><option value="<?= $c['id'] ?>" <?= $selCourse == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
      </select></div>
    <div><label>Year</label>
      <select name="year"><?php for ($y=1;$y<=3;$y++): ?><option value="<?= $y ?>" <?= $selYear == $y ? 'selected' : '' ?>>Year <?= $y ?></option><?php endfor; ?></select></div>
    <div><label>Section</label><input name="section" value="<?= e($selSection) ?>" style="width:70px"></div>
    <button class="btn btn-primary btn-sm">Load</button>
  </form>
</div>

<?php if ($selCourse): ?>
<div class="card">
  <h2>Add / Update Slot</h2>
  <form method="post">
    <?= csrf_field() ?><input type="hidden" name="do" value="add">
    <input type="hidden" name="course_id" value="<?= $selCourse ?>">
    <input type="hidden" name="year" value="<?= $selYear ?>">
    <input type="hidden" name="section" value="<?= e($selSection) ?>">
    <div class="form-row">
      <div><label>Day</label>
        <select name="day_of_week"><?php foreach ($days as $dn => $d): ?><option value="<?= $dn ?>"><?= $d ?></option><?php endforeach; ?></select></div>
      <div><label>Period</label>
        <select name="period_no"><?php for ($p=1;$p<=$maxPeriod;$p++): ?><option value="<?= $p ?>">Period <?= $p ?></option><?php endfor; ?></select></div>
      <div><label>Subject</label>
        <select name="subject_id"><option value="0">— (Free / Other) —</option>
          <?php foreach ($subjects as $s): ?><option value="<?= $s['id'] ?>"><?= e($s['code'] . ' ' . $s['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div><label>Faculty</label><input name="faculty" placeholder="Lecturer name"></div>
      <div><label>Start</label><input type="time" name="start_time" value="09:30" required></div>
      <div><label>End</label><input type="time" name="end_time" value="10:20" required></div>
    </div>
    <p style="margin-top:14px"><button class="btn btn-primary">Save Slot</button></p>
  </form>
</div>

<div class="card">
  <h2>Weekly Timetable — Year <?= $selYear ?>, Section <?= e($selSection) ?></h2>
  <div class="table-wrap"><table class="tt-table">
    <tr><th>Day</th><?php for ($p=1;$p<=$maxPeriod;$p++): ?><th>P<?= $p ?></th><?php endfor; ?></tr>
    <?php foreach ($days as $dn => $d): ?>
    <tr>
      <td><b><?= $d ?></b></td>
      <?php for ($p=1;$p<=$maxPeriod;$p++): $sl = $slots[$dn][$p] ?? null; ?>
      <td>
        <?php if ($sl): ?>
          <div class="tt-sub"><?= e($sl['sub_code'] ?: '—') ?></div>
          <div class="tt-fac"><?= e($sl['faculty']) ?></div>
          <div class="tt-fac"><?= e(substr($sl['start_time'],0,5)) ?>–<?= e(substr($sl['end_time'],0,5)) ?></div>
          <form method="post" onsubmit="return confirm('Remove slot?')"><?= csrf_field() ?>
            <input type="hidden" name="do" value="del"><input type="hidden" name="id" value="<?= $sl['id'] ?>">
            <button class="btn btn-sm btn-link" style="color:var(--err)">remove</button></form>
        <?php else: ?><span style="color:#c3c9d6">—</span><?php endif; ?>
      </td>
      <?php endfor; ?>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
