<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notify.php';
require_admin();
csrf_verify();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'add') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if ($title && $content) {
        $pdo->prepare('INSERT INTO notices (title, content, audience, posted_by) VALUES (?,?,?,?)')
            ->execute([$title, $content, $_POST['audience'] ?? 'All', $_SESSION['user_id']]);
        /* optional broadcast to students by email (no-op unless MAIL_ENABLED) */
        if (!empty($_POST['broadcast']) && MAIL_ENABLED) {
            $emails = $pdo->query("SELECT email FROM students WHERE status='Active' AND email IS NOT NULL")->fetchAll();
            $sent = 0;
            foreach ($emails as $row) { if (send_email($row['email'], '[MTDC Notice] ' . $title, $content)) $sent++; }
            flash('success', "Notice published and emailed to $sent students.");
        } else {
            flash('success', 'Notice published.' . (!empty($_POST['broadcast']) ? ' (Email broadcast skipped — MAIL_ENABLED is off.)' : ''));
        }
    } else {
        flash('error', 'Title and content are required.');
    }
    header('Location: notices.php'); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'del') {
    $pdo->prepare('DELETE FROM notices WHERE id=?')->execute([(int)$_POST['id']]);
    flash('success', 'Notice deleted.');
    header('Location: notices.php'); exit;
}

$notices = $pdo->query('SELECT * FROM notices ORDER BY id DESC')->fetchAll();
$pageTitle = 'Notices';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">Notices &amp; Announcements</h1></div>

<div class="card">
  <h2>Publish New Notice</h2>
  <form method="post">
    <?= csrf_field() ?><input type="hidden" name="do" value="add">
    <div class="form-row">
      <div style="grid-column: span 2"><label>Title *</label><input name="title" required></div>
      <div><label>Audience</label>
        <select name="audience"><option>All</option><option>Students</option></select></div>
    </div>
    <label>Content *</label><textarea name="content" rows="4" required></textarea>
    <p style="margin-top:10px;font-size:13.5px">
      <label style="display:inline-flex;gap:6px;align-items:center;margin:0;font-weight:600">
        <input type="checkbox" name="broadcast" value="1" style="width:auto"> Also email this notice to all active students
      </label>
    </p>
    <p style="margin-top:14px"><button class="btn btn-primary">Publish</button></p>
  </form>
</div>

<div class="card">
  <h2>All Notices (<?= count($notices) ?>)</h2>
  <?php foreach ($notices as $n): ?>
  <div class="notice">
    <h3><?= e($n['title']) ?></h3>
    <div class="meta"><?= e(date('d M Y, h:i A', strtotime($n['created_at']))) ?> · Audience: <?= e($n['audience']) ?></div>
    <p><?= nl2br(e($n['content'])) ?></p>
    <form method="post" style="margin-top:8px" onsubmit="return confirm('Delete this notice?')"><?= csrf_field() ?>
      <input type="hidden" name="do" value="del"><input type="hidden" name="id" value="<?= $n['id'] ?>">
      <button class="btn btn-sm btn-danger">Delete</button></form>
  </div>
  <?php endforeach; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
