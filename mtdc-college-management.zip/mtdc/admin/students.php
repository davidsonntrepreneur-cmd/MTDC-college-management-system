<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notify.php';
require_admin();
csrf_verify();
$pdo = db();

$action = $_GET['action'] ?? 'list';
$courses = $pdo->query('SELECT * FROM courses ORDER BY name')->fetchAll();

/* ---------- CREATE / UPDATE ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['do'] ?? '', ['add', 'edit'])) {
    $id   = (int)($_POST['id'] ?? 0);
    $adm  = strtoupper(trim($_POST['admission_no'] ?? ''));
    $name = trim($_POST['full_name'] ?? '');
    if ($adm === '' || $name === '') {
        flash('error', 'Admission number and full name are required.');
        header('Location: students.php'); exit;
    }
    $fields = [
        'admission_no'   => $adm,
        'full_name'      => $name,
        'email'          => trim($_POST['email'] ?? '') ?: null,
        'phone'          => trim($_POST['phone'] ?? '') ?: null,
        'dob'            => $_POST['dob'] ?: null,
        'gender'         => $_POST['gender'] ?? 'Male',
        'address'        => trim($_POST['address'] ?? '') ?: null,
        'guardian_name'  => trim($_POST['guardian_name'] ?? '') ?: null,
        'guardian_phone' => trim($_POST['guardian_phone'] ?? '') ?: null,
        'course_id'      => (int)$_POST['course_id'],
        'year'           => (int)$_POST['year'],
        'section'        => trim($_POST['section'] ?? 'A'),
        'admission_date' => $_POST['admission_date'] ?: null,
        'status'         => $_POST['status'] ?? 'Active',
    ];

    try {
        if ($_POST['do'] === 'add') {
            $pdo->beginTransaction();
            // login account: username = admission no, default password = dob (ddmmyyyy) or Mtdc@123
            $defaultPass = $fields['dob'] ? date('dmY', strtotime($fields['dob'])) : 'Mtdc@123';
            $pdo->prepare('INSERT INTO users (username, password_hash, role) VALUES (?,?,?)')
                ->execute([$adm, password_hash($defaultPass, PASSWORD_BCRYPT), 'student']);
            $uid = (int)$pdo->lastInsertId();
            $cols = implode(',', array_keys($fields));
            $ph   = implode(',', array_fill(0, count($fields), '?'));
            $pdo->prepare("INSERT INTO students (user_id, $cols) VALUES (?, $ph)")
                ->execute(array_merge([$uid], array_values($fields)));
            $pdo->commit();
            notify_student($fields['email'], $fields['phone'],
                'Your MTDC Student Portal Login',
                "Dear {$name},\n\nYour student account for the " . COLLEGE_NAME . " portal has been created.\nUsername: {$adm}\nPassword: {$defaultPass}\n\nPlease change your password after first login.",
                "MTDC Portal login - Username: {$adm}, Password: {$defaultPass}. Change it after login.");
            flash('success', "Student added. Login → username: $adm, password: $defaultPass");
        } else {
            $set = implode(', ', array_map(fn($k) => "$k = ?", array_keys($fields)));
            $pdo->prepare("UPDATE students SET $set WHERE id = ?")
                ->execute(array_merge(array_values($fields), [$id]));
            // keep username in sync with admission no
            $pdo->prepare('UPDATE users u JOIN students s ON s.user_id=u.id SET u.username=? WHERE s.id=?')
                ->execute([$adm, $id]);
            flash('success', 'Student details updated.');
        }
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', str_contains($e->getMessage(), 'Duplicate') ? 'Admission number already exists.' : 'Database error while saving.');
    }
    header('Location: students.php'); exit;
}

/* ---------- RESET PASSWORD ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'resetpass') {
    $sid = (int)$_POST['id'];
    $new = 'Mtdc@' . random_int(1000, 9999);
    $pdo->prepare('UPDATE users u JOIN students s ON s.user_id=u.id SET u.password_hash=? WHERE s.id=?')
        ->execute([password_hash($new, PASSWORD_BCRYPT), $sid]);
    flash('success', "Password reset. New password: $new");
    header('Location: students.php'); exit;
}

/* ---------- DELETE ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'delete') {
    $sid = (int)$_POST['id'];
    // deleting the user cascades to student -> attendance/fees/marks
    $pdo->prepare('DELETE u FROM users u JOIN students s ON s.user_id=u.id WHERE s.id=?')->execute([$sid]);
    flash('success', 'Student record deleted.');
    header('Location: students.php'); exit;
}

/* ---------- EDIT FORM DATA ---------- */
$editing = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $st = $pdo->prepare('SELECT * FROM students WHERE id=?');
    $st->execute([(int)$_GET['id']]);
    $editing = $st->fetch();
}

/* ---------- LIST + FILTERS ---------- */
$search   = trim($_GET['q'] ?? '');
$fCourse  = (int)($_GET['course'] ?? 0);
$fYear    = (int)($_GET['year'] ?? 0);
$where = []; $args = [];
if ($search !== '') { $where[] = '(s.full_name LIKE ? OR s.admission_no LIKE ?)'; $args[] = "%$search%"; $args[] = "%$search%"; }
if ($fCourse) { $where[] = 's.course_id = ?'; $args[] = $fCourse; }
if ($fYear)   { $where[] = 's.year = ?';      $args[] = $fYear; }
$sql = 'SELECT s.*, c.code course_code FROM students s JOIN courses c ON c.id=s.course_id'
     . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
     . ' ORDER BY s.admission_no LIMIT 300';
$st = $pdo->prepare($sql);
$st->execute($args);
$students = $st->fetchAll();

$pageTitle = 'Students';
require __DIR__ . '/../includes/header.php';
$v = fn($k, $d = '') => e($editing[$k] ?? $d);
?>
<div class="page-head">
  <h1 class="page-title">Student Management</h1>
  <?php if ($action !== 'add' && !$editing): ?>
    <a class="btn btn-primary" href="students.php?action=add">+ Add Student</a>
  <?php endif; ?>
</div>

<?php if ($action === 'add' || $editing): ?>
<div class="card">
  <h2><?= $editing ? 'Edit Student — ' . e($editing['full_name']) : 'Add New Student' ?></h2>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="<?= $editing ? 'edit' : 'add' ?>">
    <?php if ($editing): ?><input type="hidden" name="id" value="<?= (int)$editing['id'] ?>"><?php endif; ?>
    <div class="form-row">
      <div><label>Admission No *</label><input name="admission_no" required value="<?= $v('admission_no') ?>"></div>
      <div><label>Full Name *</label><input name="full_name" required value="<?= $v('full_name') ?>"></div>
      <div><label>Email</label><input type="email" name="email" value="<?= $v('email') ?>"></div>
      <div><label>Phone</label><input name="phone" value="<?= $v('phone') ?>"></div>
      <div><label>Date of Birth</label><input type="date" name="dob" value="<?= $v('dob') ?>"></div>
      <div><label>Gender</label>
        <select name="gender"><?php foreach (['Male','Female','Other'] as $g): ?>
          <option <?= ($editing['gender'] ?? '') === $g ? 'selected' : '' ?>><?= $g ?></option>
        <?php endforeach; ?></select></div>
      <div><label>Course *</label>
        <select name="course_id" required>
          <?php foreach ($courses as $c): ?>
          <option value="<?= $c['id'] ?>" <?= ($editing['course_id'] ?? 0) == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div><label>Year</label>
        <select name="year"><?php for ($y = 1; $y <= 3; $y++): ?>
          <option value="<?= $y ?>" <?= ($editing['year'] ?? 1) == $y ? 'selected' : '' ?>>Year <?= $y ?></option>
        <?php endfor; ?></select></div>
      <div><label>Section</label><input name="section" value="<?= $v('section', 'A') ?>" maxlength="5"></div>
      <div><label>Admission Date</label><input type="date" name="admission_date" value="<?= $v('admission_date', date('Y-m-d')) ?>"></div>
      <div><label>Guardian Name</label><input name="guardian_name" value="<?= $v('guardian_name') ?>"></div>
      <div><label>Guardian Phone</label><input name="guardian_phone" value="<?= $v('guardian_phone') ?>"></div>
      <div><label>Status</label>
        <select name="status"><?php foreach (['Active','Inactive','Passed Out'] as $s): ?>
          <option <?= ($editing['status'] ?? 'Active') === $s ? 'selected' : '' ?>><?= $s ?></option>
        <?php endforeach; ?></select></div>
    </div>
    <label>Address</label><textarea name="address" rows="2"><?= $v('address') ?></textarea>
    <p style="margin-top:16px">
      <button class="btn btn-primary">Save Student</button>
      <a class="btn btn-link" href="students.php">Cancel</a>
    </p>
    <?php if (!$editing): ?>
    <p style="font-size:12.5px;color:var(--muted)">A login account is created automatically: <b>username = admission no</b>, <b>password = date of birth (DDMMYYYY)</b> (or Mtdc@123 if DOB not given).</p>
    <?php endif; ?>
  </form>
</div>
<?php endif; ?>

<div class="card">
  <form class="inline-form" method="get">
    <div><label>Search</label><input name="q" value="<?= e($search) ?>" placeholder="Name / admission no"></div>
    <div><label>Course</label>
      <select name="course"><option value="0">All courses</option>
        <?php foreach ($courses as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $fCourse == $c['id'] ? 'selected' : '' ?>><?= e($c['code']) ?></option>
        <?php endforeach; ?>
      </select></div>
    <div><label>Year</label>
      <select name="year"><option value="0">All</option>
        <?php for ($y = 1; $y <= 3; $y++): ?><option value="<?= $y ?>" <?= $fYear == $y ? 'selected' : '' ?>>Year <?= $y ?></option><?php endfor; ?>
      </select></div>
    <button class="btn btn-primary btn-sm">Filter</button>
  </form>
</div>

<div class="card">
  <h2>Students (<?= count($students) ?>)</h2>
  <div class="table-wrap"><table>
    <tr><th>Adm. No</th><th>Name</th><th>Course</th><th>Yr/Sec</th><th>Phone</th><th>Status</th><th>Actions</th></tr>
    <?php if (!$students): ?><tr><td colspan="7">No students found. Click “+ Add Student” to begin.</td></tr><?php endif; ?>
    <?php foreach ($students as $s): ?>
    <tr>
      <td><b><?= e($s['admission_no']) ?></b></td>
      <td><?= e($s['full_name']) ?></td>
      <td><?= e($s['course_code']) ?></td>
      <td><?= (int)$s['year'] ?>-<?= e($s['section']) ?></td>
      <td><?= e($s['phone']) ?></td>
      <td><span class="badge <?= $s['status'] === 'Active' ? 'badge-ok' : 'badge-warn' ?>"><?= e($s['status']) ?></span></td>
      <td style="white-space:nowrap">
        <a class="btn btn-sm btn-gold" href="students.php?action=edit&id=<?= $s['id'] ?>">Edit</a>
        <form method="post" style="display:inline" onsubmit="return confirm('Reset password for <?= e($s['admission_no']) ?>?')">
          <?= csrf_field() ?><input type="hidden" name="do" value="resetpass"><input type="hidden" name="id" value="<?= $s['id'] ?>">
          <button class="btn btn-sm btn-primary">Reset Pwd</button>
        </form>
        <form method="post" style="display:inline" onsubmit="return confirm('Delete <?= e($s['full_name']) ?> permanently? This removes attendance, fees and results too.')">
          <?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $s['id'] ?>">
          <button class="btn btn-sm btn-danger">Delete</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
