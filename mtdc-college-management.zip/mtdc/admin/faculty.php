<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notify.php';
require_admin();
csrf_verify();
$pdo = db();
$courses = $pdo->query('SELECT * FROM courses ORDER BY name')->fetchAll();

/* ---------- ADD / EDIT FACULTY ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['do'] ?? '', ['add', 'edit'])) {
    $id   = (int)($_POST['id'] ?? 0);
    $emp  = strtoupper(trim($_POST['emp_no'] ?? ''));
    $name = trim($_POST['full_name'] ?? '');
    if ($emp === '' || $name === '') {
        flash('error', 'Employee no. and full name are required.');
        header('Location: faculty.php'); exit;
    }
    $fields = [
        'emp_no'      => $emp,
        'full_name'   => $name,
        'email'       => trim($_POST['email'] ?? '') ?: null,
        'phone'       => trim($_POST['phone'] ?? '') ?: null,
        'designation' => trim($_POST['designation'] ?? '') ?: 'Lecturer',
        'department'  => trim($_POST['department'] ?? '') ?: null,
        'status'      => $_POST['status'] ?? 'Active',
    ];
    try {
        if ($_POST['do'] === 'add') {
            $pdo->beginTransaction();
            $defaultPass = 'Mtdc@' . random_int(1000, 9999);
            $pdo->prepare('INSERT INTO users (username, password_hash, role) VALUES (?,?,?)')
                ->execute([$emp, password_hash($defaultPass, PASSWORD_BCRYPT), 'faculty']);
            $uid = (int)$pdo->lastInsertId();
            $cols = implode(',', array_keys($fields));
            $ph   = implode(',', array_fill(0, count($fields), '?'));
            $pdo->prepare("INSERT INTO faculty (user_id, $cols) VALUES (?, $ph)")
                ->execute(array_merge([$uid], array_values($fields)));
            $pdo->commit();
            notify_student($fields['email'], $fields['phone'],
                'Your MTDC Faculty Portal Login',
                "Dear {$name},\n\nYour faculty account for the " . COLLEGE_NAME . " portal has been created.\nUsername: {$emp}\nPassword: {$defaultPass}\n\nPlease change your password after first login.",
                "MTDC Portal login - Username: {$emp}, Password: {$defaultPass}. Please change it after login.");
            flash('success', "Faculty added. Login → username: $emp, password: $defaultPass");
        } else {
            $set = implode(', ', array_map(fn($k) => "$k = ?", array_keys($fields)));
            $pdo->prepare("UPDATE faculty SET $set WHERE id = ?")
                ->execute(array_merge(array_values($fields), [$id]));
            $pdo->prepare('UPDATE users u JOIN faculty f ON f.user_id=u.id SET u.username=? WHERE f.id=?')
                ->execute([$emp, $id]);
            flash('success', 'Faculty details updated.');
        }
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', str_contains($e->getMessage(), 'Duplicate') ? 'Employee number already exists.' : 'Database error while saving.');
    }
    header('Location: faculty.php'); exit;
}

/* ---------- RESET PASSWORD / DELETE ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'resetpass') {
    $fid = (int)$_POST['id'];
    $new = 'Mtdc@' . random_int(1000, 9999);
    $pdo->prepare('UPDATE users u JOIN faculty f ON f.user_id=u.id SET u.password_hash=? WHERE f.id=?')
        ->execute([password_hash($new, PASSWORD_BCRYPT), $fid]);
    flash('success', "Password reset. New password: $new");
    header('Location: faculty.php'); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'delete') {
    $pdo->prepare('DELETE u FROM users u JOIN faculty f ON f.user_id=u.id WHERE f.id=?')->execute([(int)$_POST['id']]);
    flash('success', 'Faculty record deleted.');
    header('Location: faculty.php'); exit;
}

/* ---------- CLASS ASSIGNMENTS ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'assign') {
    try {
        $pdo->prepare('INSERT INTO faculty_classes (faculty_id, course_id, year, section) VALUES (?,?,?,?)')
            ->execute([(int)$_POST['faculty_id'], (int)$_POST['course_id'], (int)$_POST['year'], trim($_POST['section'] ?: 'A')]);
        flash('success', 'Class assigned to faculty.');
    } catch (PDOException $e) { flash('error', 'That class is already assigned to this faculty member.'); }
    header('Location: faculty.php'); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'unassign') {
    $pdo->prepare('DELETE FROM faculty_classes WHERE id=?')->execute([(int)$_POST['id']]);
    flash('success', 'Class assignment removed.');
    header('Location: faculty.php'); exit;
}

/* ---------- DATA ---------- */
$editing = null;
if (($_GET['action'] ?? '') === 'edit' && isset($_GET['id'])) {
    $st = $pdo->prepare('SELECT * FROM faculty WHERE id=?');
    $st->execute([(int)$_GET['id']]);
    $editing = $st->fetch();
}
$facultyList = $pdo->query('SELECT f.*, u.username FROM faculty f JOIN users u ON u.id=f.user_id ORDER BY f.emp_no')->fetchAll();
$assignments = $pdo->query('SELECT fc.*, f.full_name, c.code course_code FROM faculty_classes fc
    JOIN faculty f ON f.id=fc.faculty_id JOIN courses c ON c.id=fc.course_id
    ORDER BY f.full_name, c.code, fc.year')->fetchAll();

$pageTitle = 'Faculty';
require __DIR__ . '/../includes/header.php';
$v = fn($k, $d = '') => e($editing[$k] ?? $d);
?>
<div class="page-head">
  <h1 class="page-title">Faculty Management</h1>
  <?php if (!$editing): ?><a class="btn btn-primary" href="faculty.php?action=add">+ Add Faculty</a><?php endif; ?>
</div>

<?php if (($_GET['action'] ?? '') === 'add' || $editing): ?>
<div class="card">
  <h2><?= $editing ? 'Edit Faculty — ' . e($editing['full_name']) : 'Add New Faculty' ?></h2>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="<?= $editing ? 'edit' : 'add' ?>">
    <?php if ($editing): ?><input type="hidden" name="id" value="<?= (int)$editing['id'] ?>"><?php endif; ?>
    <div class="form-row">
      <div><label>Employee No *</label><input name="emp_no" required value="<?= $v('emp_no') ?>" placeholder="FAC001"></div>
      <div><label>Full Name *</label><input name="full_name" required value="<?= $v('full_name') ?>"></div>
      <div><label>Email</label><input type="email" name="email" value="<?= $v('email') ?>"></div>
      <div><label>Phone</label><input name="phone" value="<?= $v('phone') ?>"></div>
      <div><label>Designation</label><input name="designation" value="<?= $v('designation', 'Lecturer') ?>"></div>
      <div><label>Department</label><input name="department" value="<?= $v('department') ?>" placeholder="e.g. Computer Science"></div>
      <div><label>Status</label>
        <select name="status"><?php foreach (['Active','Inactive'] as $s): ?>
          <option <?= ($editing['status'] ?? 'Active') === $s ? 'selected' : '' ?>><?= $s ?></option>
        <?php endforeach; ?></select></div>
    </div>
    <p style="margin-top:16px">
      <button class="btn btn-primary">Save Faculty</button>
      <a class="btn btn-link" href="faculty.php">Cancel</a>
    </p>
    <?php if (!$editing): ?>
    <p style="font-size:12.5px;color:var(--muted)">A login account is created automatically: <b>username = employee no</b>, with a random password shown after saving (and emailed/SMSed if notifications are enabled).</p>
    <?php endif; ?>
  </form>
</div>
<?php endif; ?>

<div class="card">
  <h2>Faculty (<?= count($facultyList) ?>)</h2>
  <div class="table-wrap"><table>
    <tr><th>Emp No</th><th>Name</th><th>Designation</th><th>Department</th><th>Phone</th><th>Status</th><th>Actions</th></tr>
    <?php if (!$facultyList): ?><tr><td colspan="7">No faculty added yet.</td></tr><?php endif; ?>
    <?php foreach ($facultyList as $f): ?>
    <tr>
      <td><b><?= e($f['emp_no']) ?></b></td>
      <td><?= e($f['full_name']) ?></td>
      <td><?= e($f['designation']) ?></td>
      <td><?= e($f['department']) ?></td>
      <td><?= e($f['phone']) ?></td>
      <td><span class="badge <?= $f['status'] === 'Active' ? 'badge-ok' : 'badge-warn' ?>"><?= e($f['status']) ?></span></td>
      <td style="white-space:nowrap">
        <a class="btn btn-sm btn-gold" href="faculty.php?action=edit&id=<?= $f['id'] ?>">Edit</a>
        <form method="post" style="display:inline" onsubmit="return confirm('Reset password for <?= e($f['emp_no']) ?>?')">
          <?= csrf_field() ?><input type="hidden" name="do" value="resetpass"><input type="hidden" name="id" value="<?= $f['id'] ?>">
          <button class="btn btn-sm btn-primary">Reset Pwd</button>
        </form>
        <form method="post" style="display:inline" onsubmit="return confirm('Delete <?= e($f['full_name']) ?>?')">
          <?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $f['id'] ?>">
          <button class="btn btn-sm btn-danger">Delete</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>

<div class="grid grid-2">
  <div class="card">
    <h2>Assign Class to Faculty</h2>
    <form method="post">
      <?= csrf_field() ?><input type="hidden" name="do" value="assign">
      <div class="form-row">
        <div><label>Faculty</label>
          <select name="faculty_id" required><option value="">— Select —</option>
            <?php foreach ($facultyList as $f): if ($f['status'] !== 'Active') continue; ?>
            <option value="<?= $f['id'] ?>"><?= e($f['emp_no'] . ' — ' . $f['full_name']) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div><label>Course</label>
          <select name="course_id"><?php foreach ($courses as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['code']) ?></option><?php endforeach; ?></select></div>
        <div><label>Year</label>
          <select name="year"><?php for ($y=1;$y<=3;$y++): ?><option value="<?= $y ?>">Year <?= $y ?></option><?php endfor; ?></select></div>
        <div><label>Section</label><input name="section" value="A" maxlength="5"></div>
      </div>
      <p style="margin-top:14px"><button class="btn btn-gold">Assign Class</button></p>
    </form>
    <p style="font-size:12.5px;color:var(--muted)">Faculty can mark attendance and enter marks <b>only</b> for classes assigned to them here.</p>
  </div>

  <div class="card">
    <h2>Current Assignments</h2>
    <div class="table-wrap" style="max-height:300px;overflow-y:auto"><table>
      <tr><th>Faculty</th><th>Class</th><th></th></tr>
      <?php if (!$assignments): ?><tr><td colspan="3">No classes assigned yet.</td></tr><?php endif; ?>
      <?php foreach ($assignments as $a): ?>
      <tr>
        <td><?= e($a['full_name']) ?></td>
        <td><?= e($a['course_code']) ?> · Year <?= (int)$a['year'] ?> · Sec <?= e($a['section']) ?></td>
        <td><form method="post" onsubmit="return confirm('Remove this assignment?')"><?= csrf_field() ?>
          <input type="hidden" name="do" value="unassign"><input type="hidden" name="id" value="<?= $a['id'] ?>">
          <button class="btn btn-sm btn-danger">✕</button></form></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
