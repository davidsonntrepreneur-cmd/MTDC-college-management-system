<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
$pdo = db();

$totStudents = (int)$pdo->query("SELECT COUNT(*) FROM students WHERE status='Active'")->fetchColumn();
$totCourses  = (int)$pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();
$today       = date('Y-m-d');

$att = $pdo->prepare("SELECT
    SUM(status='Present') p, SUM(status='Absent') a
    FROM attendance WHERE att_date = ?");
$att->execute([$today]);
$attRow = $att->fetch();
$presentToday = (int)($attRow['p'] ?? 0);
$absentToday  = (int)($attRow['a'] ?? 0);

$feesThisMonth = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM fee_payments
    WHERE MONTH(payment_date)=MONTH(CURDATE()) AND YEAR(payment_date)=YEAR(CURDATE())")->fetchColumn();
$q = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM fee_payments WHERE academic_year=?");
$q->execute([CURRENT_ACADEMIC_YEAR]);
$feesTotal = (float)$q->fetchColumn();

$recentPayments = $pdo->query("SELECT fp.receipt_no, fp.amount, fp.payment_date, fp.mode, s.full_name, s.admission_no
    FROM fee_payments fp JOIN students s ON s.id=fp.student_id
    ORDER BY fp.id DESC LIMIT 6")->fetchAll();

$courseCounts = $pdo->query("SELECT c.name, COUNT(s.id) cnt
    FROM courses c LEFT JOIN students s ON s.course_id=c.id AND s.status='Active'
    GROUP BY c.id ORDER BY cnt DESC")->fetchAll();

$notices = $pdo->query("SELECT * FROM notices ORDER BY id DESC LIMIT 4")->fetchAll();

$pageTitle = 'Admin Dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head">
  <h1 class="page-title">Admin Dashboard</h1>
  <span class="badge badge-info">Academic Year <?= e(CURRENT_ACADEMIC_YEAR) ?></span>
</div>

<div class="grid grid-4">
  <div class="stat"><div class="num"><?= $totStudents ?></div><div class="lbl">Active Students</div></div>
  <div class="stat green"><div class="num"><?= $presentToday ?></div><div class="lbl">Present Today</div></div>
  <div class="stat red"><div class="num"><?= $absentToday ?></div><div class="lbl">Absent Today</div></div>
  <div class="stat gold"><div class="num"><?= money($feesThisMonth) ?></div><div class="lbl">Fees Collected (This Month)</div></div>
</div>

<div class="grid grid-2" style="margin-top:20px">
  <div class="card">
    <h2>Recent Fee Payments</h2>
    <div class="table-wrap"><table>
      <tr><th>Receipt</th><th>Student</th><th class="num">Amount</th><th>Date</th></tr>
      <?php if (!$recentPayments): ?><tr><td colspan="4">No payments recorded yet.</td></tr><?php endif; ?>
      <?php foreach ($recentPayments as $p): ?>
      <tr>
        <td><?= e($p['receipt_no']) ?></td>
        <td><?= e($p['full_name']) ?> <small>(<?= e($p['admission_no']) ?>)</small></td>
        <td class="num"><?= money($p['amount']) ?></td>
        <td><?= e(date('d-m-Y', strtotime($p['payment_date']))) ?></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
    <p style="margin-top:10px"><a class="btn btn-sm btn-primary" href="fees.php">Go to Fees →</a></p>
  </div>

  <div class="card">
    <h2>Students by Course</h2>
    <div class="table-wrap"><table>
      <tr><th>Course</th><th class="num">Students</th></tr>
      <?php foreach ($courseCounts as $c): ?>
      <tr><td><?= e($c['name']) ?></td><td class="num"><?= (int)$c['cnt'] ?></td></tr>
      <?php endforeach; ?>
    </table></div>
    <p style="margin-top:10px">
      <a class="btn btn-sm btn-primary" href="students.php">Manage Students →</a>
      <a class="btn btn-sm btn-gold" href="attendance.php">Mark Attendance →</a>
    </p>
  </div>
</div>

<div class="card">
  <h2>Latest Notices</h2>
  <?php if (!$notices): ?><p>No notices posted.</p><?php endif; ?>
  <?php foreach ($notices as $n): ?>
  <div class="notice">
    <h3><?= e($n['title']) ?></h3>
    <div class="meta"><?= e(date('d M Y, h:i A', strtotime($n['created_at']))) ?> · <?= e($n['audience']) ?></div>
    <p><?= nl2br(e($n['content'])) ?></p>
  </div>
  <?php endforeach; ?>
  <a class="btn btn-sm btn-primary" href="notices.php">Manage Notices →</a>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
