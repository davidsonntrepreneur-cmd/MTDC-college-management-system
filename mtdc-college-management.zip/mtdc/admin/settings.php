<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
csrf_verify();
$pdo = db();

/* ---------- CHANGE ADMIN PASSWORD ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'password') {
    $cur = $_POST['current'] ?? '';
    $new = $_POST['new'] ?? '';
    $con = $_POST['confirm'] ?? '';
    $st = $pdo->prepare('SELECT password_hash FROM users WHERE id=?');
    $st->execute([$_SESSION['user_id']]);
    $hash = $st->fetchColumn();
    if (!password_verify($cur, $hash)) {
        flash('error', 'Current password is incorrect.');
    } elseif (strlen($new) < 8) {
        flash('error', 'New password must be at least 8 characters.');
    } elseif ($new !== $con) {
        flash('error', 'New passwords do not match.');
    } else {
        $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')
            ->execute([password_hash($new, PASSWORD_BCRYPT), $_SESSION['user_id']]);
        flash('success', 'Admin password changed successfully.');
    }
    header('Location: settings.php'); exit;
}

/* ---------- MANAGE COURSES ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'course_add') {
    try {
        $pdo->prepare('INSERT INTO courses (code, name, duration_years) VALUES (?,?,?)')
            ->execute([strtoupper(trim($_POST['code'])), trim($_POST['name']), (int)($_POST['duration'] ?: 3)]);
        flash('success', 'Course added.');
    } catch (PDOException $e) { flash('error', 'Course code already exists.'); }
    header('Location: settings.php'); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'course_del') {
    try {
        $pdo->prepare('DELETE FROM courses WHERE id=?')->execute([(int)$_POST['id']]);
        flash('success', 'Course deleted.');
    } catch (PDOException $e) { flash('error', 'Cannot delete: students are enrolled in this course.'); }
    header('Location: settings.php'); exit;
}

$courses = $pdo->query('SELECT c.*, (SELECT COUNT(*) FROM students s WHERE s.course_id=c.id) cnt FROM courses c ORDER BY c.name')->fetchAll();
$pageTitle = 'Settings';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">Settings</h1></div>

<div class="grid grid-2">
  <div class="card">
    <h2>Change Admin Password</h2>
    <form method="post">
      <?= csrf_field() ?><input type="hidden" name="do" value="password">
      <label>Current Password</label><input type="password" name="current" required>
      <label>New Password (min 8 chars)</label><input type="password" name="new" required minlength="8">
      <label>Confirm New Password</label><input type="password" name="confirm" required>
      <p style="margin-top:14px"><button class="btn btn-primary">Change Password</button></p>
    </form>
  </div>

  <div class="card">
    <h2>Courses Offered</h2>
    <form method="post" class="inline-form" style="margin-bottom:14px">
      <?= csrf_field() ?><input type="hidden" name="do" value="course_add">
      <div><label>Code</label><input name="code" required placeholder="BSC-MPC" style="width:110px"></div>
      <div style="flex:1"><label>Course Name</label><input name="name" required placeholder="B.Sc (M.P.C)"></div>
      <div><label>Years</label><input type="number" name="duration" value="3" min="1" max="5" style="width:70px"></div>
      <button class="btn btn-gold btn-sm">Add</button>
    </form>
    <div class="table-wrap"><table>
      <tr><th>Code</th><th>Name</th><th class="num">Students</th><th></th></tr>
      <?php foreach ($courses as $c): ?>
      <tr>
        <td><b><?= e($c['code']) ?></b></td><td><?= e($c['name']) ?></td><td class="num"><?= (int)$c['cnt'] ?></td>
        <td><?php if (!$c['cnt']): ?>
          <form method="post" onsubmit="return confirm('Delete course <?= e($c['code']) ?>?')"><?= csrf_field() ?>
            <input type="hidden" name="do" value="course_del"><input type="hidden" name="id" value="<?= $c['id'] ?>">
            <button class="btn btn-sm btn-danger">✕</button></form>
        <?php endif; ?></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
</div>

<div class="card">
  <h2>System Info</h2>
  <table>
    <tr><td>Institution</td><td><b><?= e(COLLEGE_NAME) ?>, <?= e(COLLEGE_PLACE) ?></b></td></tr>
    <tr><td>Current Academic Year</td><td><b><?= e(CURRENT_ACADEMIC_YEAR) ?></b> <small>(edit in <code>config/db.php</code>)</small></td></tr>
    <tr><td>Database</td><td><code><?= e(DB_NAME) ?></code> @ <code><?= e(DB_HOST) ?></code></td></tr>
    <tr><td>Email Notifications</td><td><span class="badge <?= MAIL_ENABLED ? 'badge-ok' : 'badge-warn' ?>"><?= MAIL_ENABLED ? 'Enabled' : 'Disabled' ?></span> <small>(MAIL_ENABLED in <code>config/db.php</code>)</small></td></tr>
    <tr><td>SMS Notifications</td><td><span class="badge <?= SMS_ENABLED ? 'badge-ok' : 'badge-warn' ?>"><?= SMS_ENABLED ? 'Enabled' : 'Disabled' ?></span> <small>(SMS_ENABLED + API key in <code>config/db.php</code>; log at <code>logs/notifications.log</code>)</small></td></tr>
    <tr><td>PHP Version</td><td><?= e(PHP_VERSION) ?></td></tr>
  </table>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
