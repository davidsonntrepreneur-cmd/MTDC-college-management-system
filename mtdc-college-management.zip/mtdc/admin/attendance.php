<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
csrf_verify();
$pdo = db();

$courses = $pdo->query('SELECT * FROM courses ORDER BY name')->fetchAll();

/* ---------- SAVE ATTENDANCE ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'mark') {
    $date = $_POST['att_date'] ?: date('Y-m-d');
    $statuses = $_POST['status'] ?? [];   // [student_id => Present|Absent]
    $stmt = $pdo->prepare('INSERT INTO attendance (student_id, att_date, status, marked_by)
                           VALUES (?,?,?,?)
                           ON DUPLICATE KEY UPDATE status = VALUES(status), marked_by = VALUES(marked_by)');
    $n = 0;
    foreach ($statuses as $sid => $stv) {
        if (in_array($stv, ['Present', 'Absent'])) {
            $stmt->execute([(int)$sid, $date, $stv, $_SESSION['user_id']]);
            $n++;
        }
    }
    flash('success', "Attendance saved for $n students on " . date('d-m-Y', strtotime($date)) . '.');
    header('Location: attendance.php?course=' . (int)$_POST['course'] . '&year=' . (int)$_POST['year'] . '&date=' . $date); exit;
}

/* ---------- SELECTION ---------- */
$selCourse = (int)($_GET['course'] ?? 0);
$selYear   = (int)($_GET['year'] ?? 1);
$selDate   = $_GET['date'] ?? date('Y-m-d');

$students = [];
if ($selCourse) {
    $st = $pdo->prepare("SELECT s.*, a.status att_status
        FROM students s
        LEFT JOIN attendance a ON a.student_id = s.id AND a.att_date = ?
        WHERE s.course_id = ? AND s.year = ? AND s.status='Active'
        ORDER BY s.admission_no");
    $st->execute([$selDate, $selCourse, $selYear]);
    $students = $st->fetchAll();
}

/* ---------- MONTHLY SUMMARY ---------- */
$summary = [];
if ($selCourse) {
    $st = $pdo->prepare("SELECT s.id, s.admission_no, s.full_name,
        COUNT(a.id) total, SUM(a.status='Present') present
        FROM students s
        LEFT JOIN attendance a ON a.student_id=s.id
             AND MONTH(a.att_date)=MONTH(?) AND YEAR(a.att_date)=YEAR(?)
        WHERE s.course_id=? AND s.year=? AND s.status='Active'
        GROUP BY s.id ORDER BY s.admission_no");
    $st->execute([$selDate, $selDate, $selCourse, $selYear]);
    $summary = $st->fetchAll();
}

$pageTitle = 'Attendance';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">Attendance Management</h1></div>

<div class="card">
  <form class="inline-form" method="get">
    <div><label>Course</label>
      <select name="course" required>
        <option value="">— Select course —</option>
        <?php foreach ($courses as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $selCourse == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
        <?php endforeach; ?>
      </select></div>
    <div><label>Year</label>
      <select name="year"><?php for ($y = 1; $y <= 3; $y++): ?>
        <option value="<?= $y ?>" <?= $selYear == $y ? 'selected' : '' ?>>Year <?= $y ?></option>
      <?php endfor; ?></select></div>
    <div><label>Date</label><input type="date" name="date" value="<?= e($selDate) ?>" max="<?= date('Y-m-d') ?>"></div>
    <button class="btn btn-primary btn-sm">Load Students</button>
  </form>
</div>

<?php if ($selCourse && $students): ?>
<div class="card">
  <h2>Mark Attendance — <?= e(date('d-m-Y', strtotime($selDate))) ?> (<?= count($students) ?> students)</h2>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="mark">
    <input type="hidden" name="course" value="<?= $selCourse ?>">
    <input type="hidden" name="year" value="<?= $selYear ?>">
    <input type="hidden" name="att_date" value="<?= e($selDate) ?>">
    <p class="no-print" style="margin-bottom:10px">
      <button type="button" class="btn btn-sm btn-gold" onclick="setAll('Present')">All Present</button>
      <button type="button" class="btn btn-sm btn-danger" onclick="setAll('Absent')">All Absent</button>
    </p>
    <div class="table-wrap"><table>
      <tr><th>#</th><th>Adm. No</th><th>Name</th><th>Status</th></tr>
      <?php foreach ($students as $i => $s):
          $cur = $s['att_status'] ?? 'Present'; ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><b><?= e($s['admission_no']) ?></b></td>
        <td><?= e($s['full_name']) ?></td>
        <td class="att-row">
          <label><input type="radio" name="status[<?= $s['id'] ?>]" value="Present" <?= $cur === 'Present' ? 'checked' : '' ?>> Present</label>
          <label><input type="radio" name="status[<?= $s['id'] ?>]" value="Absent" <?= $cur === 'Absent' ? 'checked' : '' ?>> Absent</label>
        </td>
      </tr>
      <?php endforeach; ?>
    </table></div>
    <p style="margin-top:14px"><button class="btn btn-primary">Save Attendance</button></p>
  </form>
</div>

<div class="card">
  <h2>Monthly Summary — <?= e(date('F Y', strtotime($selDate))) ?></h2>
  <div class="table-wrap"><table>
    <tr><th>Adm. No</th><th>Name</th><th class="num">Days Marked</th><th class="num">Present</th><th class="num">%</th></tr>
    <?php foreach ($summary as $r):
        $pct = $r['total'] ? round($r['present'] / $r['total'] * 100, 1) : 0; ?>
    <tr>
      <td><?= e($r['admission_no']) ?></td>
      <td><?= e($r['full_name']) ?></td>
      <td class="num"><?= (int)$r['total'] ?></td>
      <td class="num"><?= (int)$r['present'] ?></td>
      <td class="num"><span class="badge <?= $pct >= 75 ? 'badge-ok' : ($r['total'] ? 'badge-err' : 'badge-warn') ?>"><?= $r['total'] ? $pct . '%' : '—' ?></span></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>

<script>
function setAll(v) {
  document.querySelectorAll('input[type=radio][value=' + v + ']').forEach(r => r.checked = true);
}
</script>
<?php elseif ($selCourse): ?>
<div class="card"><p>No active students found for this course/year. Add students first.</p></div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
