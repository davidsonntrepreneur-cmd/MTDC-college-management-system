<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notify.php';
require_admin();
csrf_verify();
$pdo = db();
$courses = $pdo->query('SELECT * FROM courses ORDER BY name')->fetchAll();

/* ---------- RECORD PAYMENT ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'pay') {
    $sid    = (int)$_POST['student_id'];
    $amount = (float)$_POST['amount'];
    if ($sid && $amount > 0) {
        $receipt = 'MTDC' . date('ymd') . strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));
        $pdo->prepare('INSERT INTO fee_payments (receipt_no, student_id, academic_year, amount, payment_date, mode, remarks, received_by)
                       VALUES (?,?,?,?,?,?,?,?)')
            ->execute([$receipt, $sid, $_POST['academic_year'] ?: CURRENT_ACADEMIC_YEAR, $amount,
                       $_POST['payment_date'] ?: date('Y-m-d'), $_POST['mode'] ?? 'Cash',
                       trim($_POST['remarks'] ?? '') ?: null, $_SESSION['user_id']]);
        $payId = (int)$pdo->lastInsertId();
        /* notify the student (no-op unless enabled in config) */
        $sq = $pdo->prepare('SELECT full_name, email, phone FROM students WHERE id=?');
        $sq->execute([$sid]);
        if ($stu = $sq->fetch()) {
            $msg = 'Dear ' . $stu['full_name'] . ', we have received your fee payment of ₹' . number_format($amount, 2)
                 . ' (Receipt: ' . $receipt . ') at ' . COLLEGE_NAME . '. Thank you.';
            notify_student($stu['email'], $stu['phone'], 'Fee Payment Received - Receipt ' . $receipt, $msg,
                'MTDC: Fee payment of Rs.' . number_format($amount, 2) . ' received. Receipt: ' . $receipt);
        }
        flash('success', "Payment recorded. Receipt no: $receipt");
        header('Location: ' . base_url('receipt.php?id=' . $payId)); exit;
    } else {
        flash('error', 'Select a student and enter a valid amount.');
    }
    header('Location: fees.php'); exit;
}

/* ---------- FEE STRUCTURE add/delete ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'structure_add') {
    $pdo->prepare('INSERT INTO fee_structure (course_id, year, academic_year, fee_type, amount, due_date) VALUES (?,?,?,?,?,?)')
        ->execute([(int)$_POST['course_id'], (int)$_POST['year'], $_POST['academic_year'] ?: CURRENT_ACADEMIC_YEAR,
                   trim($_POST['fee_type']), (float)$_POST['amount'], $_POST['due_date'] ?: null]);
    flash('success', 'Fee structure item added.');
    header('Location: fees.php#structure'); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'structure_del') {
    $pdo->prepare('DELETE FROM fee_structure WHERE id=?')->execute([(int)$_POST['id']]);
    flash('success', 'Fee structure item removed.');
    header('Location: fees.php#structure'); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'payment_del') {
    $pdo->prepare('DELETE FROM fee_payments WHERE id=?')->execute([(int)$_POST['id']]);
    flash('success', 'Payment entry deleted.');
    header('Location: fees.php'); exit;
}

/* ---------- DATA ---------- */
$studentsList = $pdo->query("SELECT s.id, s.admission_no, s.full_name, c.code
    FROM students s JOIN courses c ON c.id=s.course_id
    WHERE s.status='Active' ORDER BY s.admission_no")->fetchAll();

$payments = $pdo->query("SELECT fp.*, s.full_name, s.admission_no
    FROM fee_payments fp JOIN students s ON s.id=fp.student_id
    ORDER BY fp.id DESC LIMIT 100")->fetchAll();

$structure = $pdo->query("SELECT fs.*, c.code course_code
    FROM fee_structure fs JOIN courses c ON c.id=fs.course_id
    ORDER BY fs.academic_year DESC, c.code, fs.year")->fetchAll();

/* dues report: expected vs paid per student for current AY */
$dues = $pdo->prepare("SELECT s.id, s.admission_no, s.full_name, c.code course_code, s.year,
    COALESCE(fs.total_fee, 0)  AS total_fee,
    COALESCE(fp.total_paid, 0) AS total_paid
  FROM students s
  JOIN courses c ON c.id = s.course_id
  LEFT JOIN (SELECT course_id, year, SUM(amount) total_fee FROM fee_structure
             WHERE academic_year = ? GROUP BY course_id, year) fs
         ON fs.course_id = s.course_id AND fs.year = s.year
  LEFT JOIN (SELECT student_id, SUM(amount) total_paid FROM fee_payments
             WHERE academic_year = ? GROUP BY student_id) fp
         ON fp.student_id = s.id
  WHERE s.status='Active'
  ORDER BY s.admission_no");
$dues->execute([CURRENT_ACADEMIC_YEAR, CURRENT_ACADEMIC_YEAR]);
$duesRows = $dues->fetchAll();

$pageTitle = 'Fees';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1 class="page-title">Fee Management</h1>
  <span class="badge badge-info">AY <?= e(CURRENT_ACADEMIC_YEAR) ?></span></div>

<div class="grid grid-2">
  <div class="card">
    <h2>Record a Fee Payment</h2>
    <form method="post">
      <?= csrf_field() ?><input type="hidden" name="do" value="pay">
      <label>Student *</label>
      <select name="student_id" required>
        <option value="">— Select student —</option>
        <?php foreach ($studentsList as $s): ?>
        <option value="<?= $s['id'] ?>"><?= e($s['admission_no'] . ' — ' . $s['full_name'] . ' (' . $s['code'] . ')') ?></option>
        <?php endforeach; ?>
      </select>
      <div class="form-row">
        <div><label>Amount (₹) *</label><input type="number" name="amount" min="1" step="0.01" required></div>
        <div><label>Date</label><input type="date" name="payment_date" value="<?= date('Y-m-d') ?>"></div>
        <div><label>Mode</label>
          <select name="mode"><?php foreach (['Cash','UPI','Card','Bank Transfer','Cheque'] as $m): ?><option><?= $m ?></option><?php endforeach; ?></select></div>
        <div><label>Academic Year</label><input name="academic_year" value="<?= e(CURRENT_ACADEMIC_YEAR) ?>"></div>
      </div>
      <label>Remarks</label><input name="remarks" placeholder="e.g. Tuition fee 1st installment">
      <p style="margin-top:14px"><button class="btn btn-primary">Save Payment &amp; Generate Receipt No.</button></p>
    </form>
  </div>

  <div class="card" id="structure">
    <h2>Add Fee Structure Item</h2>
    <form method="post">
      <?= csrf_field() ?><input type="hidden" name="do" value="structure_add">
      <div class="form-row">
        <div><label>Course</label>
          <select name="course_id"><?php foreach ($courses as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['code']) ?></option><?php endforeach; ?></select></div>
        <div><label>Year</label>
          <select name="year"><?php for ($y=1;$y<=3;$y++): ?><option value="<?= $y ?>">Year <?= $y ?></option><?php endfor; ?></select></div>
        <div><label>Fee Type</label><input name="fee_type" required placeholder="Tuition Fee"></div>
        <div><label>Amount (₹)</label><input type="number" name="amount" min="1" step="0.01" required></div>
        <div><label>Academic Year</label><input name="academic_year" value="<?= e(CURRENT_ACADEMIC_YEAR) ?>"></div>
        <div><label>Due Date</label><input type="date" name="due_date"></div>
      </div>
      <p style="margin-top:14px"><button class="btn btn-gold">Add Item</button></p>
    </form>
    <div class="table-wrap" style="max-height:260px;overflow-y:auto"><table>
      <tr><th>AY</th><th>Course</th><th>Yr</th><th>Type</th><th class="num">Amount</th><th></th></tr>
      <?php foreach ($structure as $f): ?>
      <tr>
        <td><?= e($f['academic_year']) ?></td><td><?= e($f['course_code']) ?></td><td><?= (int)$f['year'] ?></td>
        <td><?= e($f['fee_type']) ?></td><td class="num"><?= money($f['amount']) ?></td>
        <td><form method="post" onsubmit="return confirm('Remove this fee item?')"><?= csrf_field() ?>
          <input type="hidden" name="do" value="structure_del"><input type="hidden" name="id" value="<?= $f['id'] ?>">
          <button class="btn btn-sm btn-danger">✕</button></form></td>
      </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
</div>

<div class="card">
  <h2>Dues Report — <?= e(CURRENT_ACADEMIC_YEAR) ?></h2>
  <div class="table-wrap"><table>
    <tr><th>Adm. No</th><th>Name</th><th>Course</th><th class="num">Total Fee</th><th class="num">Paid</th><th class="num">Balance</th><th>Status</th></tr>
    <?php foreach ($duesRows as $d):
        $bal = $d['total_fee'] - $d['total_paid']; ?>
    <tr>
      <td><?= e($d['admission_no']) ?></td>
      <td><?= e($d['full_name']) ?></td>
      <td><?= e($d['course_code']) ?> Y<?= (int)$d['year'] ?></td>
      <td class="num"><?= money($d['total_fee']) ?></td>
      <td class="num"><?= money($d['total_paid']) ?></td>
      <td class="num"><b><?= money(max($bal, 0)) ?></b></td>
      <td><?php if ($d['total_fee'] == 0): ?><span class="badge badge-warn">No structure</span>
          <?php elseif ($bal <= 0): ?><span class="badge badge-ok">Paid</span>
          <?php else: ?><span class="badge badge-err">Due</span><?php endif; ?></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>

<div class="card">
  <h2>Recent Payments (last 100)</h2>
  <div class="table-wrap"><table>
    <tr><th>Receipt</th><th>Student</th><th class="num">Amount</th><th>Date</th><th>Mode</th><th>Remarks</th><th></th></tr>
    <?php foreach ($payments as $p): ?>
    <tr>
      <td><b><?= e($p['receipt_no']) ?></b></td>
      <td><?= e($p['full_name']) ?> <small>(<?= e($p['admission_no']) ?>)</small></td>
      <td class="num"><?= money($p['amount']) ?></td>
      <td><?= e(date('d-m-Y', strtotime($p['payment_date']))) ?></td>
      <td><?= e($p['mode']) ?></td>
      <td><?= e($p['remarks']) ?></td>
      <td style="white-space:nowrap"><a class="btn btn-sm btn-gold" href="<?= base_url('receipt.php?id=' . $p['id']) ?>" target="_blank">🖨 Receipt</a>
      <form method="post" style="display:inline" onsubmit="return confirm('Delete this payment entry?')"><?= csrf_field() ?>
        <input type="hidden" name="do" value="payment_del"><input type="hidden" name="id" value="<?= $p['id'] ?>">
        <button class="btn btn-sm btn-danger">✕</button></form></td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
