<?php
/**
 * Session + authentication helpers
 */
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

require_once __DIR__ . '/../config/db.php';

/* ---------- CSRF ---------- */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}
function csrf_verify(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
            http_response_code(403);
            die('Invalid request (CSRF check failed). Go back and try again.');
        }
    }
}

/* ---------- Auth ---------- */
function attempt_login(string $username, string $password): bool {
    $stmt = db()->prepare('SELECT * FROM users WHERE username = ? AND is_active = 1');
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id']  = (int)$user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        db()->prepare('UPDATE users SET last_login = NOW() WHERE id = ?')->execute([$user['id']]);
        if ($user['role'] === 'student') {
            $s = db()->prepare('SELECT id, full_name FROM students WHERE user_id = ?');
            $s->execute([$user['id']]);
            if ($row = $s->fetch()) {
                $_SESSION['student_id']   = (int)$row['id'];
                $_SESSION['student_name'] = $row['full_name'];
            }
        } elseif ($user['role'] === 'faculty') {
            $f = db()->prepare('SELECT id, full_name FROM faculty WHERE user_id = ?');
            $f->execute([$user['id']]);
            if ($row = $f->fetch()) {
                $_SESSION['faculty_id']   = (int)$row['id'];
                $_SESSION['faculty_name'] = $row['full_name'];
            }
        }
        return true;
    }
    return false;
}

function is_logged_in(): bool { return isset($_SESSION['user_id']); }
function current_role(): ?string { return $_SESSION['role'] ?? null; }

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: ' . base_url('index.php'));
        exit;
    }
}
function require_admin(): void {
    require_login();
    if (current_role() !== 'admin') { http_response_code(403); die('Access denied.'); }
}
function require_student(): void {
    require_login();
    if (current_role() !== 'student') { http_response_code(403); die('Access denied.'); }
}
function require_faculty(): void {
    require_login();
    if (current_role() !== 'faculty') { http_response_code(403); die('Access denied.'); }
}
/** URL of the home page for the currently logged-in role. */
function role_home(): string {
    return match (current_role()) {
        'admin'   => 'admin/dashboard.php',
        'faculty' => 'faculty/dashboard.php',
        default   => 'student/dashboard.php',
    };
}

function logout(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/* ---------- Misc helpers ---------- */
function e(?string $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function base_url(string $path = ''): string {
    // works whether app is at web root or in a subfolder like /mtdc
    static $base = null;
    if ($base === null) {
        $script = $_SERVER['SCRIPT_NAME'] ?? '/';
        // strip known subdirs (admin/, student/) to find app root
        $dir = rtrim(str_replace('\\', '/', dirname($script)), '/');
        foreach (['/admin', '/student', '/faculty'] as $sub) {
            if (str_ends_with($dir, $sub)) { $dir = substr($dir, 0, -strlen($sub)); }
        }
        $base = $dir === '' ? '/' : $dir . '/';
    }
    return $base . ltrim($path, '/');
}

function flash(string $key, ?string $msg = null): ?string {
    if ($msg !== null) { $_SESSION['flash'][$key] = $msg; return null; }
    $m = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $m;
}

function money(float|string $n): string { return '₹' . number_format((float)$n, 2); }
