<?php
/**
 * Notification helpers — email + SMS
 * Both are safe no-ops until enabled in config/db.php.
 * Every attempt is logged to logs/notifications.log so the office
 * can verify what was sent (or would have been sent).
 */
require_once __DIR__ . '/../config/db.php';

function notify_log(string $channel, string $to, string $subject, string $status): void {
    $dir = __DIR__ . '/../logs';
    if (!is_dir($dir)) { @mkdir($dir, 0775, true); @file_put_contents($dir . '/.htaccess', "Require all denied\n"); }
    @file_put_contents(
        $dir . '/notifications.log',
        sprintf("[%s] %s | to: %s | %s | %s\n", date('Y-m-d H:i:s'), strtoupper($channel), $to, $subject, $status),
        FILE_APPEND
    );
}

/** Send an email (uses PHP mail(); works on most shared hosting). */
function send_email(?string $to, string $subject, string $body): bool {
    if (!$to || !filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
    if (!MAIL_ENABLED) { notify_log('email', $to, $subject, 'SKIPPED (MAIL_ENABLED=false)'); return false; }
    $headers = 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM . ">\r\n"
             . "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n";
    $ok = @mail($to, $subject, $body, $headers);
    notify_log('email', $to, $subject, $ok ? 'SENT' : 'FAILED');
    return $ok;
}

/**
 * Send an SMS via HTTP gateway. Pre-wired for Fast2SMS-style APIs;
 * adjust the URL/fields below to match your provider's documentation.
 */
function send_sms(?string $phone, string $message): bool {
    $phone = preg_replace('/\D/', '', (string)$phone);
    if (strlen($phone) < 10) return false;
    $phone = substr($phone, -10);
    if (!SMS_ENABLED || SMS_API_KEY === '') { notify_log('sms', $phone, mb_substr($message, 0, 40) . '…', 'SKIPPED (SMS_ENABLED=false)'); return false; }

    $ch = curl_init('https://www.fast2sms.com/dev/bulkV2');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query([
            'route'    => 'q',
            'message'  => $message,
            'numbers'  => $phone,
        ]),
        CURLOPT_HTTPHEADER     => ['authorization: ' . SMS_API_KEY],
    ]);
    $resp = curl_exec($ch);
    $ok = $resp !== false && curl_getinfo($ch, CURLINFO_HTTP_CODE) < 300;
    curl_close($ch);
    notify_log('sms', $phone, mb_substr($message, 0, 40) . '…', $ok ? 'SENT' : 'FAILED');
    return $ok;
}

/** Convenience: notify a student over both channels. */
function notify_student(?string $email, ?string $phone, string $subject, string $body, ?string $smsText = null): void {
    send_email($email, $subject, $body);
    send_sms($phone, $smsText ?? $body);
}
