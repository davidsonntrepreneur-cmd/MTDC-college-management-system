</main>
<footer class="footer">
  &copy; <?= date('Y') ?> <?= e(COLLEGE_NAME) ?>, Palamaner &middot; College Management System
</footer>
</body>
</html>
