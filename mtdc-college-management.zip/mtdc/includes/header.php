<?php
require_once __DIR__ . '/auth.php';
$pageTitle = $pageTitle ?? 'Portal';
$role = current_role();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> | MTDC Palamaner</title>
<link rel="stylesheet" href="<?= base_url('assets/style.css') ?>">
</head>
<body>
<header class="topbar">
  <div class="brand">
    <div class="brand-logo">MT</div>
    <div>
      <div class="brand-name"><?= e(COLLEGE_NAME) ?></div>
      <div class="brand-sub"><?= e(COLLEGE_PLACE) ?></div>
    </div>
  </div>
  <?php if (is_logged_in()): ?>
  <div class="topbar-right">
    <span class="user-chip">
      <?= e($role === 'admin' ? 'Administrator'
          : ($role === 'faculty' ? ($_SESSION['faculty_name'] ?? $_SESSION['username'])
          : ($_SESSION['student_name'] ?? $_SESSION['username']))) ?>
    </span>
    <a class="btn btn-sm btn-outline" href="<?= base_url('logout.php') ?>">Logout</a>
  </div>
  <?php endif; ?>
</header>

<?php if (is_logged_in()): ?>
<nav class="mainnav">
  <?php if ($role === 'admin'): ?>
    <a href="<?= base_url('admin/dashboard.php') ?>">Dashboard</a>
    <a href="<?= base_url('admin/students.php') ?>">Students</a>
    <a href="<?= base_url('admin/faculty.php') ?>">Faculty</a>
    <a href="<?= base_url('admin/attendance.php') ?>">Attendance</a>
    <a href="<?= base_url('admin/fees.php') ?>">Fees</a>
    <a href="<?= base_url('admin/results.php') ?>">Results</a>
    <a href="<?= base_url('admin/subjects.php') ?>">Subjects</a>
    <a href="<?= base_url('admin/timetable.php') ?>">Timetable</a>
    <a href="<?= base_url('admin/notices.php') ?>">Notices</a>
    <a href="<?= base_url('admin/settings.php') ?>">Settings</a>
  <?php elseif ($role === 'faculty'): ?>
    <a href="<?= base_url('faculty/dashboard.php') ?>">Home</a>
    <a href="<?= base_url('faculty/attendance.php') ?>">Attendance</a>
    <a href="<?= base_url('faculty/marks.php') ?>">Marks Entry</a>
    <a href="<?= base_url('faculty/students.php') ?>">My Students</a>
    <a href="<?= base_url('faculty/profile.php') ?>">Profile</a>
  <?php else: ?>
    <a href="<?= base_url('student/dashboard.php') ?>">Home</a>
    <a href="<?= base_url('student/attendance.php') ?>">My Attendance</a>
    <a href="<?= base_url('student/fees.php') ?>">My Fees</a>
    <a href="<?= base_url('student/results.php') ?>">My Results</a>
    <a href="<?= base_url('student/timetable.php') ?>">Timetable</a>
    <a href="<?= base_url('student/profile.php') ?>">My Profile</a>
  <?php endif; ?>
</nav>
<?php endif; ?>

<main class="container">
<?php foreach (['success' => 'ok', 'error' => 'err'] as $k => $cls):
    if ($m = flash($k)): ?>
  <div class="alert alert-<?= $cls ?>"><?= e($m) ?></div>
<?php endif; endforeach; ?>
